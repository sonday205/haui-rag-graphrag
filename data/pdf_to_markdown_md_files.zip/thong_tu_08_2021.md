# thong_tu_08_2021

> Nguồn: OCR từ PDF ảnh chụp bằng Tesseract (vie). Có thể còn lỗi nhận dạng ở dấu tiếng Việt, con dấu/chữ ký và bảng phức tạp.


## Trang 1

gười ký: Cổng Thông tin điện tử Chính phủ
Email: thongtinchinhphu@)chinhphu.vn

Cơ quan: Văn phòng Chính phủ
CHINHPHUI.V NThời gian ký: 27.04.2021 09:11:07 +07:00

BỘ GIÁO DỤC VÀ ĐÀO TẠO CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc

Só-¬24—⁄2921/TT-BGDĐT Hà Nội, ngày ÂÊ tháng 03 năm 2021
VĂN PHÒNG ( CHẾ PHỦ |
CÔNG VĂN ĐẾN THÔNG TỰ

Ban hành Quy chê đào tạo trình độ đại học _. cÚNG THÌNG ŸN BỀN TỪ OINH PHÙ ]

Giờ......t Ngày ...“kÍM,........
. ©:
Kính chuyên:... „TñI.(. gi)... ĐỀN là Š3 RỢPẾO tEĐ00ĐĐES
Cũn Tuiật Giáo dục ngày 14 tháng 6 năm 2019; Ngy../đ[2O2 4...

Căn cứ Luật Giáo dục đại học ngày 18 tháng 6 năm 2012;

Căn cú Luật sửa đổi, bổ sưng một số điều của Luật Giáo dục đại học ngày
19 tháng 11 năm 2018;

Căn cứ Nghị định số 69/2017/NĐ-CP ngày 25 tháng 05 năm 2017 của Chính
phủ quy định chức năng, nhiệm vụ, quyên bạn và cơ cấu tổ chức của Bộ Giáo đục và
Đào tạo;

Căn cứ Nghị định số 99/2019/NĐ-CP ngày 30 tháng 12 năm 2019 của Chính
phủ quy định chỉ tiết và hướng dẫn thì hành một số điều của Luật sửa đổi, bổ sung
một số điều của Luật Giáo dục đại học;

Theo đề nghị của Vụ trưởng Vụ Giáo đục Đại học;

Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Thông tư ban hành Quy chế
đào tạo trình độ đại học.

Điều 1. Ban hành kèm theo Thông tư này Quy chế đảo tạo trình độ đại học.

Điều 2. Thông tư này có hiệu lực thi hành từ ngàyđŸ tháng Z năm 2021, áp
dụng đối với các khóa tuyển sinh sau ngày thông tư có hiệu lực thi hành và thay
thế Quyết định số 25/2006/QĐ-BGDĐT ngày 26 tháng 6 năm 2006 của Bộ
trưởng Bộ Giáo dục và Đào tạo ban hành quy chế đào tạo đại học và cao đẳng hệ
chính quy; Quyết định số 43/2007/QĐ-BGDĐT ngày 15 tháng 8 năm 2007 của
Bộ trưởng Bộ Giáo dục và Đào tạo ban hành quy chế đào tạo đại học và cao
đẳng hệ chính quy theo hệ thống tín chỉ; Thông tư số 57/2012/TT-BGDĐT ngày
27 tháng 12 năm 2012 sửa đổi, bổ sung một số điều của quy chế đào tạo đại học
và cao đẳng hệ chính quy ban hành kèm theo Quyết định số 43/2007/QĐ-
BGDĐT ngày 1Š tháng § năm 2007 của Bộ trưởng Bộ Giáo dục và Đào tạo;
Thông tư số 06/2017/TT-BGDĐT ngày 15 tháng 3 năm 2017của Bộ trưởng Bộ
Giáo dục và Đào tạo ban hành quy chế đào tạo vừa làm vừa học trình độ đại
học; Quyết định số 22/QĐ-BGDĐT ngày 26 tháng 6 năm 2001 của Bộ trưởng
Bộ Giáo dục và Đào tạo quy định về đảo tạo để cấp bằng tốt nghiệp đại học thứ


## Trang 2

bai; Thông tư số 10/2018/TT-BGDĐT ngày 30 tháng 3 năm 2018 của Bộ trưởng
Bộ Giáo dục và Đào tạo ban hành quy định về đào tạo bằng tốt nghiệp thứ 2
trình độ đại học, trình độ cao đẳng nhóm ngành đào tạo giáo viên; Thông tư số
07/2017/TT-BGDĐT ngày l§ tháng 3 năm 2017 của Bộ trưởng Bộ Giáo dục và
Đào tạo ban hành quy định về liên kết đào tạo trình độ đại học:

Điều 3. Chánh Văn phòng, Vụ trưởng Vụ Giáo dục Đại học, Thủ trưởng „
các đơn vị có liên quan thuộc Bộ Giáo dục và Đào tạo; giám đốc đại học, học
viện, hiệu trưởng trường đại học; trường của cơ quan nhà nước, tổ chức chính
trị, tổ chức chính trị - xã hội, các tổ chức, cá nhân liên quan chịu trách nhiệm thi

hành Thông tư nay

Nơi nhận:

- Văn phòng Quốc hội;

~ Văn phòng Chính phủ;

- Ủy ban VHGDTNTNNĐ của Quếc hội;
- Ban Tuyên giáo Trung ương;

- Bộ trưởng (để báo cáo);

- Kiểm toán Nhà nước;

- Cục KTVBQPPL (Bộ Tư pháp);

- Công báo;

- Như Điều 3;

- Cổng thông tin điện tử của Chính phủ;
- Cổng thông tin điện tử của Bộ GDĐT;
- Lưu: VT, Vụ PC, Vụ GDĐH.

XT. BỘ TRƯỞNG


## Trang 3

BỘ GIÁO DỤC VÀ ĐÀO TẠO CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
Độc lập - Tự do - Hạnh phúc

QUY CHÉ ĐÀO TẠO TRÌNH ĐỘ ĐẠI HỌC

(Ban hành kèm theo Thông fư số @Ÿ#†(Ó /2021/TT-BGDĐT
ngàu|‡ tháng 3 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tao)

Chương I
NHỮNG QUY ĐỊNH CHUNG
Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng

1. Quy chế này quy.định chung về tổ chức và quản lý đào tạo trình độ
đại học, bao gồm: Chương trình đào tạo và thời gian học tập; hình thức và
phương thức tổ chức đảo tạo; lập kế hoạch và tổ chức giảng dạy; đánh giá kết
quả học tập và cấp bằng tốt nghiệp; những quy định khác đối với sinh viên.

2. Quy chế này áp dụng đối với các đại học, học viện, trường đại học;
trường của cơ qưàn nhà nước, tô chức chính trị, tổ chức chính trị - xã hội có
nhiệm vụ đảo tạo trình độ đại học (sau đây gọi là cơ sở đào tạo), các tổ chức,
cá nhân liên quan trong đào tạo theo hình thức chính quy và hình thức vừa làm
vừa học. Các chương trình đào tạo đo cơ sở giáo dục nước ngoài cấp bằng bao
gồm câ các chương trình liên kết đào tạo được áp dụng quy chế này hoặc quy
định của cơ sở đào tạo cấp bằng theo thỏa thuận liên kết, hợp tác giữa các bên
nhưng không trái với những quy định của quy chế này.

3. Quy chế này là căn cứ để cơ sở đào tạo xây đựng và ban hành các văn
bản quy định cụ thể (sau đây gọi là quy chế của cơ sở đào tạo), bao gồm cả
việc tổ chức đào tạo trình độ đại học và trình độ đào tạo các ngành chuyên sâu
đặc thù quy định tại điểm a khoán 1 Điều 14 Nghị định số 99/2019/NĐ-CP
ngày 30 tháng 12 năm 2019 của Chính phủ quy định chỉ tiết và hướng dẫn thi
hành một số điều của Luật sửa đổi, bổ sung một số điều của Luật Giáo dục đại học.

Điều 2. Chương trình đào tạo và thời gian học tập

1. Chương trình đào tạo được xây đựng theo đơn vị tín chỉ, cấu trúc từ
các môn học hoặc học phần (sau đây gọi chung là học phần), trong đó phải có
đủ các học phần bắt buộc và đáp ứng chuẩn chương trình đào tạo theo quy
định hiện hành của Bộ Giáo dục và Đào tạo. Trong trường hợp đào tạo song


## Trang 4

2

ngành hoặc ngành chính - ngành phụ, chương trình đảo tạo phải thể hiện rõ
khối lượng học tập chung và riêng theo từng ngành.

2. Nội dung, chuẩn đầu ra của chương trình đảo tạo áp dụng chung đối
với các hình thức, phương thức tổ chức đào tạo và đối tượng người học khác
nhau. Đối với người đã tốt nghiệp trình độ khác hoặc ngành khác, khối lượng
học tập thực tế được xác định trên cơ sở công nhận, hoặc chuyển đổi tín chỉ đã
tích lũy và miễn trừ học phần trong chương trình đào tạo trước.

3. Chương trình đào tạo phải được công khai đối với người học trước
khi tuyển sinh và khi bắt đầu khóa học; những thay đổi, điều chỉnh liên quan
đến chương trình đào tạo được thực hiện theo quy định hiện hành và công bế
trước khi áp dụng, không gây tác động bắt lợi cho sinh viên.

4. Đối với mỗi hình thức đào tạo, chương trình đào tạo cần cung cấp kế
hoạch học tập chuẩn toàn khoá để định hướng cho sinh viên.

a) Thời gian theo kế hoạch học tập chuẩn toàn khoá đối với hình thức
đào tạo chính quy phải phù hợp với thời gian quy định trong khung cơ cấu hệ
thống giáo dục quốc dân, đồng thời đảm bảo đa số sinh viên hoàn thành
chương trình đảo tạo;

b) Thời gian theo kế hoạch học tập chuẩn toàn khoá đối với hình thức
đào tạo vừa làm vừa học đài hơn tối thiểu 20% so với hình thức đảo tạo chính
quy của cùng chương trình đào tạo.

5. Thời gian tối đa để sinh viên hoàn thành khoá học được quy định
trong quy chế của cơ sở đào tạo, nhưng không vượt quá 02 lần thời gian theo
kế hoạch học tập chuân toàn khoá đối với mỗi hình thức đào tạo. Đối với sinh
viên học liên thông đã được miễn trừ khối lượng tín chỉ tích lũy, thời gian tối
đa để sinh viên hoàn thành khóa học được xác định trên cơ sở thời gian theo
kế hoạch học tập chuẩn toàn khoá giảm tương ứng với khối lượng được miễn trừ.

Điều 3. Phương thức tổ chức đào tạo

1. Đào tạo theo niên chế:

a) Là phương thức tổ chức đào tạo theo lớp học tương đối có định đối
với tất cả các học phần bắt buộc của chương trình đào tạo trong toàn khoá học,
cho phép sinh viên cùng lớp thực hiện theo kế hoạch học tập chuẩn và theo
một thời khóa biểu chung trừ những học phần tự chọn hoặc học lại;

b) Sinh viên được đánh giá đạt tiến độ học tập bình thường sẽ được học

tiếp năm sau theo kế hoạch học tập chuẩn và đăng ký học lại những học phần
chưa đạt theo quy định trong chương trình đào tạo;


## Trang 5

3

c) Sinh viên được đánh giá không đạt tiến độ học tập bình thường sẽ
phải học cùng sinh viên khóa sau để học lại các học phần chưa đạt theo quy
định trong chương trình đào tạo.

2. Đào tạo theo tín chỉ:

a) Là phương thức tổ chức đào tạo theo từng lớp học phân, cho phép
sinh viên tích lũy tín chỉ của từng học phần và thực hiện chương trình đào tạo
theo kế hoạch học tập của cá nhân, phù hợp với kế hoạch giáng dạy của cơ sở
đào tạo;

b) Sinh viên không đạt một học phần bất buộc sẽ phải học lại học phần
đó hoặc học một học phần tương đương theo quy định trong chương trình đào
tạo, hoặc học một học phần thay thế nếu học phần đó không còn được giảng dạy;

c) Sinh viên không đạt một học phần tự chọn sẽ phải học lại học phần
đó hoặc có thể chọn học một học phần tự chọn khác theo quy định trong
chương trình đảo tạo.

3. Cơ sở đào tạo lựa chọn, áp dụng phương thức tô chức đào tạo như sau:

a) Đào tạo theo tín chỉ, áp dụng thống nhất cho tất cả các khóa và hình
thức đào tạo;

b) Đào tạo theo niên chế, áp dụng thống nhất cho tất cả các khóa và
hình thức đào tạo;

€) Áp dụng đào tạo theo tín chỉ cho một số khóa hoặc cho một hình thức
đào tạo; áp dụng đào tạo theo niên chế cho một số khóa khác hoặc hình thức
đào tạo còn lại.

Điều 4. Hình thức đào tạo

1. Đào tạo chính quy:

a) Các hoạt động giảng dạy được thực hiện tại cơ sở đào tạo, riêng
những hoạt động thực hành, thực tập, trải nghiệm thực tế và giảng dạy trực
tuyến có thể thực hiện ngoài cơ sở đào tạo;

b) Thời gian tô chức hoạt động giáng dạy trong khoảng từ 06 giờ đến 20
giờ các ngày trong tuần từ thứ 2 đến thứ 7; thời gian tổ chức những hoạt động
đặc thù của chương trình đào tạo được thực hiện theo quy định của cơ sở đào tạo.

2. Đào tạo vừa làm vừa học:

a) Các hoạt động giảng dạy được thực hiện tại cơ sở đào tạo hoặc tại cơ
sở phôi hợp đào tạo theo quy định liên kết đào tạo tại Điều 5 của Quy chế này,


## Trang 6

4

riêng những hoạt động thực hành, thực tập, trải nghiệm thực tế và giảng dạy
trực tuyến có thể thực hiện ngoài cơ sở đào tạo, cơ sở phối hợp đào tạo;

b) Thời gian tô chức hoạt động giảng dạy linh hoạt trong ngày và trong tuần.

3. Đối với các ngành đào tạo ưu tiên phục vụ nguồn nhân lực phát triển
kinh tế - xã hội trong từng giai đoạn, Bộ Giáo dục và Đảo tạo có hướng dẫn thực
hiện các hình thức đào tạo phù hợp.

Điều 5. Liên kết đào tạo

1. Liên kết đào tạo chỉ thực hiện đối với hình thức vừa làm vừa học theo
quy định tại khoản 22 Điều 1 Luật sửa đổi, bỗ sung một số điều của Luật Giáo
dục đại học và theo quy định tại khoản 2, khoản 3 Điều này. Không thực hiện
việc liên kết đào tạo đối với các ngành thuộc lĩnh vực sức khoẻ có cấp chứng
chỉ hành nghà.

2. Các yêu cầu tối thiểu đối với cơ sở chủ trì đảo tạo:

a) Đã được công nhận đạt tiêu chuẩn chất lượng cơ sở giáo dục đại học
bởi tô chức kiểm định chất lượng giáo đục hợp pháp và còn hiệu lực theo quy định;

b) Chương trình đào tạo dự kiến liên kết đào tạo đã được tổ chức thực
hiện tối thiểu 03 khoá tuyển sinh liên tục theo hình thức chính quy; từ khóa
tuyển sinh năm 2024 yêu cầu chương trình đào tạo đã được công nhận đạt
chuân chất lượng theo quy định hiện hành;

©) Bảo đảm đội ngũ giảng viên cơ hữu giảng dạy tối thiểu 70% nội
dung, khối lượng chương trình đào tạo;

d) Đã ban hành quy định về liên kết và đã thâm định các điều kiện bảo
đảm chất lượng của cơ sở phối hợp đào tạo;

đ) Các cơ sở đào tạo thuộc Bộ Quốc phòng, Bộ Công an không áp dụng
điểm a, điểm b khoản này, nhưng chỉ được liên kết đào tạo với cơ sở giáo dục
thuộc cùng bộ quản lý trực tiếp và phải có văn bản giao nhiệm vụ liên kết đào
tạo của bộ quản lý trực tiếp.

3. Các yêu cầu tôi thiểu của cơ sở phối hợp đào tạo:

a) Đáp ứng các yêu cầu về môi trường sư phạm, cơ sở vật chất, thiết bị,
thư viện và cán bộ quản lý theo yêu cầu của chương trình đào tạo;

b) Đã có báo cáo tự đánh giá chất lượng cơ sở giáo dục gửi về cơ quan
nhà nước có thẩm quyền theo quy định; từ khóa tuyên sinh năm 2024 yêu cầu
đã được công nhận đạt tiêu chuẩn chất lượng cơ sở giáo dục theo quy định
hiện hành, trừ các cơ sở đảo tạo, bồi dưỡng thuộc Bộ Quốc phòng, Bộ Công an.

⁄


## Trang 7

§

4. Trách nhiệm của các bên tham gia liên kết đào tạo:

a) Cơ sở chủ trì đào tạo và cơ sở phối hợp đào tạo chịu trách nhiệm ký
kết hợp đồng liên kết đào tạo, thỏa thuận cụ thể về quyền và trách nhiệm của
các bên trong việc phối hợp tổ chức thực hiện, quản lý quá trình đạy học bảo
đảm chất lượng đào tạo và thực hiện nội dung đã thỏa thuận phù hợp với các
quy định của Quy chế này và các quy định pháp luật khác có liên quan;

b) Cơ sở chủ trì đào tạo chịu trách nhiệm quản lý chất lượng đào tạo;
báo cáo hoạt động liên kết đào tạo với Ủy ban nhân dân cấp tỉnh nơi liên kết
đào tạo trước khi tổ chức tuyển sinh; nếu cơ sở phối hợp đào tạo không
đáp ứng được các yêu cầu về bảo đảm chất lượng theo quy định của học phần
hoặc của chương trình đào tạo thì phải chuyển sinh viên về cơ sở chủ trì liên
kết để tiếp tục đào tạo theo quy định và bảo đảm quyền lợi cho sinh viên;

c) Cơ sở phối hợp đào tạo có trách nhiệm cùng cơ sở chủ trì đào tạo bảo
đảm đủ điều kiện cơ sở vật chất thực hiện đào tạo; tham gia quản lý, giảng
đạy, theo thoả thuận giữa hai bên;

d) Cơ sở chủ trì đào tạo, cơ sở phối hợp đào tg6 chịu trách nhiệm trước
pháp luật về việc thực hiện hợp đồng liên kết đào tạo; thực hiện các quy chế
về tuyển sinh, đào tạo; bảo đâm quyền lợi chính đáng cho giảng viên, sinh
viên trong suốt quá trình thực hiện hoạt động đào tạo.

Chương II
LẬP KẾ HOẠCH VÀ TÔ CHỨC GIẢNG DẠY
Điều 6. Kế hoạch giảng đạy và học tập

1. Kế hoạch giảng đạy và học tập chỉ tiết hóa việc tổ chức thực hiện các
chương trình đào tạo theo năm học, học kỳ, phù hợp với hình thức đảo tạo và
phương thức tổ chức đảo tạo.

2. Kế hoạch năm học thể hiện những mốc thời gian chính của các hoạt
động đào tạo trong năm học cho tất cả hình thức, chương trình đào tạo, được
công bố kịp thời tới các bên liên quan trước khi bắt đầu năm học. Một năm
học có 02 hoặc 03 học kỳ chính với tổng số tối thiểu 30 tuần lên lớp. Ngoài
các học kỳ chính, cơ sở đào tạo có thể tổ chức thêm học kỳ phụ.

3. Kế hoạch học kỳ bao gồm kế hoạch mở lớp, hình thức dạy và học
(trực tiếp hoặc trực tuyến), lịch học, lịch thi của các học phần được tổ chức
trong học kỳ cho các khoá, chương trình đào tạo và hình thức đào tạo. Kế
hoạch học kỳ phải được xây dựng và công bố kịp thời với đầy đủ thông tin cần thiết,
bảo đảm thuận tiện cho sinh viên xây dựng kế hoạch học tập và đăng ký học tập.

Z


## Trang 8

6

4. Thời khoá biểu thể hiện thời gian, địa điểm, hoạt động đạy và học của
từng lớp thuộc các khoá, hình thức và chương trình đào tạo. Thời khóa biêu
của các lớp học phản bình thường được bố trí đều trong các tuần của học kỳ.
Trong trường hợp cần thiết phải xếp lịch học tập trung thời gian, số giờ giảng
đối với một học phần bất kỳ không vượt quá 15 giờ/tuần và 4 giờ/ngày.

5. Quy chế của cơ sở đào tạo quy định rõ việc phân bổ các học kỳ, thời
gian, địa điểm, hình thức bố trí các giờ lên lớp theo quy định của Quy chế này.

Điều 7. Tổ chức đăng ký học tập

1. Trước khi bắt đầu mỗi học kỳ, cơ sở đào tạo hướng dẫn cho sinh viên
đăng ký học tập trên hệ thống đăng ký học tập của nhà trường.

2. Sinh viên học theo tín chỉ phải đăng ký lớp của các học phần dự định
sẽ học trong học kỳ, gồm: những học phần mới, một số học phần chưa đạt (để
học lại) và một số học phần đã đạt (đễ cải thiện điểm, nếu có) căn cứ danh
sách học phần được mở và điều kiện đăng ký của mỗi học phần.

3. Sinh viên học theo niên chế đăng ký học lại những học phần chưa đạt
dự định sẽ học trong học kỳ, đăng ký học cải thiện điểm hoặc đăng ký học
những học phần tự chọn theo quy định của chương trình đào tạo.

4. Quy chế của cơ sở đào tạo quy định quy trình, thủ tục, tổ chức quản
lý, lưu trữ việc đăng ký học tập của sinh viên ở mỗi học kỳ, việc rút bớt học
phần đã : đăng ký; quy định cụ thể giới hạn khối lượng học tập của sinh viên
trong mỗi học kỳ nằm trong khung như sau:

a) Khối lượng tối thiểu không ít hơn 2/3 khối lượng trung bình một học
kỳ theo kế hoạch học tập chuẩn;

b) Khối lượng tối đa không vượt quá 3/2 khối lượng trung bình một học
kỳ theo kế hoạch học tập chuẩn.

Điều 8. Tổ chức giảng dạy và học tập

1. Yêu cầu về tổ chức giảng dạy và học tập:

a) Phát huy năng lực chuyên môn và trách nhiệm nghề nghiệp của đội
ngũ giảng viên, phù hợp với quy định vẻ chế độ làm việc của giảng viên;

b) Phát huy vai trò chủ động đồng thời đề cao trách nhiệm của sinh

viên, tạo điều kiện và động lực để sinh viên nỗ lực học tập; giữ vững kỷ cương
học đường, nâng cao chất lượng và hiệu quả đào tạo;

©) Có cơ chế thanh tra, giám sát nội bộ và có hệ thống cải tiến chất
lượng dựa trên thu thập, đánh giá ý kiến phản hồi của người học.


## Trang 9

2. Dạy và học trực tuyến:

a) Cơ sở đào tạo được tổ chức các lớp học trực tuyến khi đáp ứng các
quy định hiện hành về ứng dụng công nghệ thông tỉn trong quản lý và tổ chức
đào tạo qua mạng; có các giải pháp bảo đảm chất lượng và minh chứng chất
lượng lớp học trực tuyến không thấp hơn chất lượng lớp học trực tiếp;

b) Đối với đào tạo chính quy và vừa làm vừa học, tối đa 30% tổng khối
lượng của chương trình đào tạo được thực hiện bằng lớp học trực tuyến. Trong
trường hợp thiên tai, dịch bệnh phức tạp và các trường hợp bất khả kháng khác,
cơ sở đào tạo thực hiện theo hướng dẫn của Bộ Giáo dục và Đào tạo.

3. Quy chế của cơ sở đào tạo quy định:

a) Việc phân công giảng viên cho các lớp học, giảng viên giảng dạy,
giảng viên hướng dẫn sinh viên làm thí nghiệm, thực hành, thực tập, đồ án,
khoá luận và thực hiện các hoạt động học tập khác;

b) Việc lấy ý kiến phản hồi của người học về các điều kiện bảo đảm
chất lượng, hiệu quả học tập đối với tất cả các lớp học của cơ sở đào tạo và
việc công khai ý kiến phản hồi của người học, bao gồm nội dung, mức độ, hình
thức công khai;

e) Trách nhiệm và quyền hạn của giảng viên được phân công giảng dạy
hoặc hướng dẫn sinh viên; trách nhiệm của các đơn vị chuyên môn và các đơn
vị quản lý, hỗ trợ liên quan;

đ) Trách nhiệm và quyền hạn của sinh viên khi tham dự các lớp học,
tham gia thí nghiệm, thực hành hoặc khi được giao thực tập, đỗ án, khoá luận
và các hoạt động học tập khác.

Chương HI
ĐÁNH GIÁ KÉT QUÁ HỌC TẬP VÀ CÁP BẰNG TÓT NGHIỆP

Điều 9. Đánh giá và tính điểm học phần

1. Đối với mỗi học phân, sinh viên được đánh giá qua tối thiểu hai điểm
thành phần, đối với các học phần có khối lượng nhỏ hơn 02 tín chỉ có thể chỉ
có một điểm đánh giá. Các điểm thành phần được đánh giá theo thang điểm
10. Phương pháp đánh giá, hình thức đánh giá và trọng số của mỗi điểm thành
phần được quy định trong đề cương chỉ tiết của mỗi học phần. Hình thức đánh
giá trực tuyến được áp đụng khi đảm bảo trung thực, công bằng và khách quan
như đánh giá trực tiếp, đồng thời đóng góp không quá 50% trọng số điểm học

LẾ


## Trang 10

§

phần; riêng việc tổ chức bảo vệ và đánh giá đồ án, khóa luận được thực hiện
trực tuyến với trọng số cao hơn khi đáp ứng thêm các điều kiện sau đây:

a) Việc đánh giá được thực hiện thông qua một hội đồng chuyên môn
gồm ít nhất 3 thành viên;

b) Hình thức bảo vệ và đánh giá trực tuyến được sự đồng thuận của các
thành viên hội đồng và người học;

c) Diễn biến của buổi báo vệ trực tuyến được ghi hình, ghi âm đầy đủ
và lưu trữ.

2. Sinh viên vắng mặt trong buổi thi, đánh giá không có lý đo chính
đáng phải nhận điểm 0. Sinh viên vắng mặt có lý do chính đáng được dự thi,
đánh giá ở một đợt khác và được tính điểm lần đầu.

3. Điểm học phần được tính từ tổng các điểm thành phần nhân với trọng
số tương ứng, làm tròn tới một chữ số thập phân và xếp loại điểm chữ như
dưới đây, trừ các trường hợp được quy định tại điểm đ khoản này.

a) Loại đạt có phân mức, áp dụng cho các học phần được tính vào điểm
trung bình học tập, bao gồm:

A: từ 8,5 đến 10,0;
B: từ 7,0 đến §,4;
C: từ 5,5 đến 6,9;
D: từ 4,0 đến 5,4.

b) Loại đạt không phân mức, áp dụng cho các học phần chỉ yêu cầu đạt,
không tính vào điểm trung bình học tập:

P: từ 5,0 trở lên.
c) Loại không đạt:
F: dưới 4.0.

đ) Một số trường hợp đặc biệt sử dụng các điểm chữ xếp loại, không
được tính vào điểm trung bình học tập:

1: Điểm chưa hoàn thiện đo được phép hoãn thi, kiểm tra;
X: Điểm chưa hoàn thiện do chưa đủ đữ liệu;

R: Điểm học phần được miễn học và công nhận tín chỉ.


## Trang 11

9

4. Học lại, thi và học cải thiện điểm:

a) Sinh viên có điểm học phần không đạt phải đăng ký học lại theo quy
định tại khoản I và khoản 2 Điều 3 của Quy chế này, trừ trường hợp quy định
tại điểm đ khoản 5 Điều này; điểm lần học cuối là điểm chính thức của học phần;

b) Sinh viên đã có điểm học phần đạt được đăng ký học lại đề cải thiện
điểm theo quy định của cơ sở đảo tạo.

5. Quy chế của cơ sở đảo tạo quy định:

a) Việc tổ chức đánh giá quá trình học tập, trải nghiệm của sinh viên,
bao gồm cả các hoạt động thí nghiệm, thực hành, làm bài tập, trình bày báo
cáo như một thành phần của học phần;

b) Việc tổ chức thi, kiểm tra, bao gồm quy định về thời gian ôn thi và
thời gian thị, việc làm đề thi, coi thi, chấm thi, phúc tra (nếu có), bảo quản bài
thi, việc hoãn thi và miễn thi;

e) Việc tổ chức đánh giá các học phân, đồ án, khóa luận, thực hành và
thực tập và các học phần đặc thù khác;

đ) Việc có yêu cầu ngưỡng điểm đạt phải cao hơn quy định tại điểm a
khoản 3 Điều này; việc áp dụng nhiều mức điểm chữ xếp loại hơn quy định
tại khoản 3 Điều này;

đ) Việc cho phép thi lại, đánh giá lại một điểm thành phần để cải thiện
điểm học phần từ không đạt thành đạt; trong trường hợp này, điểm học phần
sau khi thi lại, đánh giá lại chỉ được giới hạn ở mức điểm D hoặc điểm C;

e) Việc cho phép học lại để cải thiện điểm và quy tắc tính điểm chính
thức của học phần trong trường hợp điểm học lần sau thấp hơn.

6. Quy định của cơ sở đào tạo về đánh giá và tính điểm học phần phải
phù hợp các nguyên tắc và yêu cầu như sau:

a) Nghiêm túc, khách quan, tin cậy và trung thực;

b) Công bằng đối với tất cả sinh viên trong lớp, giữa các lớp, các khoá
và các hình thức đảo tạo.

Điều 10. Đánh giá kết quả học tập theo học kỳ, năm học

1. Kết quả học tập của sinh viên được đánh giá sau từng học kỳ hoặc
sau từng năm học, dựa trên kết quả các học phần nằm trong yêu cầu của
chương trình đào tạo mà người học đã học và có điểm theo các tiêu chí sau đây:


## Trang 12

10

a) Tổng số tín chỉ của những học phần mà sinh viên không đạt trong
một học kỳ, trong một năm học, hoặc nợ đọng từ đầu khoá học;

b) Tổng số tín chỉ của những học phần mà sinh viên đã đạt từ đầu khóa
học (số tín chỉ tích lũy), tính cả các học phần được miễn học, được công nhận tín chỉ;

c) Điểm trung bình của những học phần mà sinh viên đã học trong một
học kỳ (điểm trung bình học kỳ), trong một năm học (điểm trung bình năm
học) hoặc tính từ đầu khóa học (điểm trung bình tích lũy), tính theo điểm
chính thức của học phần và trọng số là số tín chỉ của học phần đó.

2. Để tính điểm trung bình, điểm chữ của học phần được quy đổi về
điểm số như dưới đây, trừ trường hợp quy định tại khoản 4 Điều này. Điểm
chữ nhiều mức hơn đo cơ sở đào tạo quy định (nếu có) cũng được quy đổi
sang điểm số tương ứng theo thang từ 0 tới 4.

A quy đổi thành 4;
B quy đổi thành 3;
C quy đổi thành 2;
D quy đổi thành 1;
F quy đổi thành 0.

3. Những điểm chữ không được quy định tại khoản 2 Điều này không
được tính vào các điểm trung bình học kỳ, năm học hoặc tích lũy. Những học
phần không nằm trong yêu cầu của chương trình đào tạo không được tính vào
các tiêu chí đánh giá kết quả học tập của sinh viên.

4. Cơ sở đào tạo đang đào tạo theo niên chế và sử dụng thang điểm 10
thì tính các điểm trung bình dựa trên điểm học phần theo thang điểm 10,
không quy đổi các điểm chữ về thang điểm 4. Trong trường hợp này, quy chế
của cơ sở đảo tạo quy định cụ thể các mức xử lý kết quả học tập để tương
đương và thay thế cho các quy định trong Điều 12 của Quy chế này.

5. Sinh viên được xếp loại học lực theo điểm trung bình học kỳ, điểm
trung bình năm học hoặc điểm trung bình tích lũy như sau:

a) Theo thang điểm 4:

Từ 3,6 đến 4,0: Xuất sắc;
Từ 3,2 đến cận 3,6: Giỏi;
Từ 2,5 đến cận 3,2: Khá;
Từ 2,0 đến cận 2,5: Trung bình;


## Trang 13

11

Từ 1,0 đến cận 2,0: Yếu;
Dưới 1,0: Kém.
b) Theo thang điểm 10:
Từ 9,0 đến 10,0: Xuất sắc;
Từ §,0 đến cận 9,0: Giỏi;
Từ 7,0 đến cận 8,0: Khá;
Từ 5,0 đến cận 7,0: Trung bình;
Từ 4,0 đến cận 5,0: Yếu;
Dưới 4,0: Kém.

6. Sinh viên được xếp trình độ năm học căn cứ số tín chỉ tích lũy được
từ đầu khóa học (gọi tắt là N) và số tín chỉ trung bình một năm học theo kế
hoạch học tập chuẩn (gọi tắt là M), cụ thể như sau:

a) Trình độ năm thứ nhất: N < M;

b) Trình độ năm thứ hai: M<N <2M;

e) Trình độ năm thứ ba: 2M <N < 3M;

d) Trình độ năm thứ tư: 3M <N <4M;

đ) Trình độ năm thứ năm: 4M <N < 5M.

Điều 11. Xử lý kết quả học tập theo tín chí

1. Cuối mỗi học kỳ chính, sinh viên được cảnh báo học tập dựa trên một
số điều kiện như sau:

a) Tổng số tín chỉ không đạt trong học kỳ vượt quá 50% khối lượng đã
đăng kí học trong học kỳ, hoặc tổng số tín chỉ nợ đọng từ đần khóa học vượt quá 24;

b) Điểm trung bình học kỳ đạt đưới 0,8 đối với học kỳ đầu của khóa
học, đưới 1,0 đối với các học kỳ tiếp theo;

e) Điểm trung bình tích lũy đạt đưới 1,2 đỗi với sinh viên trình độ năm
thứ nhất, dưới 1,4 đối với sinh viên trình độ năm thứ hai, dưới 1,6 đối với sinh
viên trình độ năm thứ ba hoặc đưới 1,8 đối với sinh viên các năm tiếp theo.

2. Sinh viên bị buộc thôi học trong các trường hợp:

a) Số lần cảnh báo học tập hoặc mức cảnh báo học tập vượt quá giới
hạn theo quy định của cơ sở đào tạo;


## Trang 14

12
b) Thời gian học tập vượt quá giới hạn theo quy định tại khoản Š Điều 2
của Quy chế này.
3. Quy chế của cơ sở đào tạo quy định cụ thể:

a) Việc lựa chọn áp dụng một số điều kiện cảnh báo học tập, giới hạn số
lần hoặc mức cảnh báo học tập nhưng không vượt quá 2 lần cảnh báo liên tiếp;

b) Quy trình, thủ tục cảnh báo học tập, buộc thôi học; việc thông báo
hình thức áp dụng tới sinh viên;

c) Việc bảo lưu kết quả học tập đã tích luỹ trong trường hợp sinh viên bị
buộc thôi học.

Điều 12. Xử lý kết quá học tập theo niên chế

1. Cuối mỗi năm học, sinh viên được đánh giá đạt tiến độ học tập bình
thường và được học tiếp lên năm học sau nếu đạt cả hai điều kiện:

a) Điểm trung bình năm học đạt từ 1,0 trở lên đối với năm học thứ nhất,
từ 1,2 trở lên đối với năm thứ hai và từ 1,4 đối với năm thứ ba trở đi;

b) Số tín chỉ nợ đọng từ đầu khóa không vượt quá 16.

2. Sinh viên bị buộc thôi học trong các trường hợp:

a) Điểm trung bình năm học đạt dưới 0,8;

b) Điểm trung bình tích lũy đạt dưới 1,2 sau 2 năm học, đưới 1,4 sau 3
năm học và đưới 1,6 từ sau 4 năm học trở đi; :

c) Thời gian học tập vượt quá giới hạn theo quy định tại khoản Š Điều 2
của Quy chế này.

3. Sinh viên không thuộc diện quy định tại khoản 1 và khoản 2 Điều này
được xếp lớp học cùng khoá sau để cải thiện kết quả học tập.

4. Quy chế của cơ sở đào tạo quy định cụ thể:

a) Việc lựa chọn áp dụng một số điều kiện cảnh báo học tập tương tự
quy định đối với đào tạo theo tín chỉ tại khoản 1 Điều 11 của Quy chế này;

b) Quy trình, thủ tục cảnh báo học tập (nếu có), buộc thôi học; việc
thông báo hình thức áp dụng tới sinh viên;

c) Việc bảo lưu kết quả học tập đã tích luỹ trong trường hợp sinh viên bị
buộc thôi học.


## Trang 15

13

Điều 13. Công nhận kết quả học tập và chuyển đổi tín chỉ

1. Kết quả học tập của người học đã tích lũy từ một trình độ đào tạo
khác, một ngành đảo tạo hoặc một chương trình đảo tạo khác, một khóa học
khác hoặc từ một cơ sở đào tạo khác được cơ sở đào tạo xem xét công nhận,
chuyển đổi sang tín chỉ của những học phần trong chương trình đào tạo theo học.

2. Hội đồng chuyên môn của cơ sở đào tạo xem xét công nhận, chuyển
đổi tín chỉ trên cơ sở đối sánh chuẩn đầu ra, nội dung và khối lượng học tập,
cách thức đánh giá học phần và các điều kiện bảo đảm chất lượng thực hiện
chương trình theo các cấp độ:

a) Công nhận, chuyên đổi theo từng học phần;

b) Công nhận, chuyển đổi theo từng nhóm học phần;

e) Công nhận, chuyển đổi theo cả chương trình đào tạo.

3. Cơ sở đào tạo công khai quy định việc công nhận kết quả học tập và
chuyển đổi tín chỉ. Khối lượng tối đa được công nhận, chuyển đổi không vượt
quá 50% khối lượng học tập tối thiểu của chương trình đào tạo; riêng đối với
ngành đào tạo giáo viên thực hiện theo hướng dẫn của Bộ Giáo dục và Đào tạo.

Điều 14. Công nhận tốt nghiệp và cấp bằng tốt nghiệp

1. Sinh viên được xét và công nhận tốt nghiệp khi có đủ các điều kiện sau:

a) Tích lũy đủ học phần, số tín chỉ và hoàn thành các nội dung bắt buộc
khác theo yêu cầu của chương trình đào tạo, đạt chuẩn đầu ra của chương trình
đào tạo;

b) Điểm trung bình tích lũy của toàn khóa học đạt từ trung bình trở lên;

©) Tại thời điểm xét tốt nghiệp không bị truy cứu trách nhiệm hình sự
hoặc không đang trong thời gian bị ký luật ở mức đình chỉ học tập.

2. Những sinh viên đủ điều kiện tốt nghiệp được hiệu trưởng cơ sở đào
tạo ra quyết định công nhận tốt nghiệp và cấp bằng tốt nghiệp trong thời hạn
03 tháng tính từ thời điểm sinh viên đáp ứng đầy đủ điều kiện tốt nghiệp và
hoàn thành nghĩa vụ với nhà trường.

3. Hạng tốt nghiệp được xác định căn cứ vào điểm trung bình tích lũy
toàn khoá được quy định tại khoản Š Điều 10 của Quy chế này, trong đó, hạng
tốt nghiệp của sinh viên có điểm trung bình tích lũy loại xuất sắc và giỏi sẽ bị
giảm đi một mức nếu thuộc một trong các trường hợp sau:

a) Khối lượng của các học phần phải học lại vượt quá 5% so với tổng số
tín chỉ quy định cho toàn chương trình;


## Trang 16

14

b) Sinh viên đã bị kỷ luật từ mức cảnh cáo trở lên trong thời gian học.

4. Sinh viên đã hết thời gian học tập tối đa theo quy định nhưng chưa đủ
điều kiện tốt nghiệp do chưa hoàn thành những học phần Giáo dục quốc
phòng-an ninh hoặc Giáo dục thể chất hoặc chưa đạt chuẩn đầu ra về ngoại
ngữ, công nghệ thông tin, trong thời hạn 03 năm tính từ khi thôi học được
hoàn thiện các điều kiện còn thiếu và đề nghị xét công nhận tốt nghiệp.

5. Sinh viên không tốt nghiệp được cấp chứng nhận về các học phần đã
tích luỹ trong chương trình đào tạo của cơ sở đảo tạo.

6. Quy chế của cơ sở đảo tạo quy định:

a) Quy trình, thủ tục xét và công nhận tốt nghiệp, thời gian và số lần xét
tốt nghiệp trong năm;

b) Việc bảo lưu, công nhận kết quả học tập đã tích lũy đối với sinh viên
không tốt nghiệp;

e) Việc cho phép sinh viên hết thời gian học chính quy được chuyển qua
học hình thức vừa làm vừa học, đào tạo từ xa tương ứng (nếu có) của cơ sở
đào tạo nếu còn trong thời gian học tập theo quy định đối với hình thức
chuyển đến.

Chương IV
NHỮNG QUY ĐỊNH KHÁC ĐÓI VỚI SINH VIÊN

Điều 15. Nghĩ học tạm thời, thôi học

1. Sinh viên được xin nghỉ học tạm thời và bảo lưu kết quả đã học trong
các trường hợp sau:

a) Được điều động vào lực lượng vũ trang;

b) Được cơ quan có thẳm quyền điều động, đại diện quốc gia tham dự
các kỳ thi, giải đâu quốc tế;

c) Bị ốm, thai sản hoặc tai nạn phải điều trị thời gian dài có chứng nhận
của cơ sở khám bệnh, chữa bệnh có thẩm quyền theo quy định của Bộ Y tế;

đ) Vì lý do cá nhân khác nhưng đã phải học tối thiểu 01 học kỳ ở cơ sở
đào tạo và không thuộc các trường hợp bị xem xét buộc thôi học hoặc xem xét
kỷ luật.

2. Thời gian nghỉ học tạm thời vì nhu cầu cá nhân phải được tính vào
thời gian học chính thức quy định tại khoản 5 Điều 2 của Quy chế này.


## Trang 17

15

3. Sinh viên được xin thôi học vì lý do cá nhân, trừ trường hợp bị xem
xét buộc thôi học hoặc xem xét kỷ luật. Những sinh viên này muốn quay trở
lại học phải dự tuyển đầu vào như những thí sinh khác.

4. Quy chế của cơ sở đào tạo quy định cụ thể về điều kiện, thâm quyền,
thủ tục xét nghỉ học tạm thời, tiếp nhận trở lại học và cho thôi học; việc bảo
lưu và công nhận kết quả học tập đã tích lũy đối với sinh viên xin thôi học.

Điều 16. Chuyển ngành, chuyễn nơi học, chuyển trường, chuyển
hình thức học

1. Sinh viên được xem xét chuyển sang học một chương trình, một
ngành đào tạo khác, hoặc một phân hiệu khác của cơ sở đào tạo (hoặc từ phân
hiệu về trụ sở chính) khi có đủ các điều kiện sau:

a) Không đang là sinh viên trình độ năm thứ nhất hoặc năm cuối khóa,
không thuộc điện bị xem xét buộc thôi học và còn đủ thời gian học tập theo
quy định tại khoản 5 Điều 2 của Quy chế này;

b) Sinh viên đạt điều kiện trúng tuyển của chương trình, ngành đào tạo,
của phân hiệu (hoặc trụ sở chính) trong cùng khóa tuyển sinh;

c) Cơ sở đào tạo, phân hiệu (hoặc trụ sở chính) có đủ các điều kiện bảo
đảm chất lượng, chưa vượt quá năng lực đào tạo đối với chương trình, ngành
đào tạo đó theo quy định hiện hành của Bộ Giáo đục và Đào tạo;

d) Được sự đồng ý của thủ trưởng các đơn vị chuyên môn phụ trách
chương trình, ngành đào tạo, người phụ trách phân hiệu (nơi chuyển đi và
chuyến đến) và của hiệu trưởng cơ sở đảo tạo.

2. Sinh viên được xem xét chuyển trường khi có đủ các điều kiện sau:

a) Không đang là sinh viên trình độ năm thứ nhất hoặc năm cuối khóa,
không thuộc diện bị xem xét buộc thôi học và còn đủ thời gian học tập theo
quy định tại khoản 5 Điều 2 của Quy chế này;

b) Sinh viên đạt điều kiện trúng tuyển của chương trình, ngành đảo tạo
cùng khóa tuyển sinh tại nơi chuyển đến;

e) Nơi chuyển đến có đủ các điều kiện bảo đảm chất lượng, chưa vượt
quá năng lực đào tạo đối với chương trình, ngành đào tạo đó theo quy định
hiện hành của Bộ Giáo dục và Đào tạo;

d) Được sự đồng ý của hiệu trưởng cơ sở đảo tạo xin chuyển đi và cơ sở
đào tạo xin chuyên đến.


## Trang 18

l6

3. Sinh viên được xem xét chuyển từ hình thức chính quy sang hình
thức vừa làm vừa học hoặc đào tạo từ xa của cơ sở đào tạo nếu còn đủ thời
gian học tập theo quy định đối với hình thức chuyền đến.

4. Quy chế của cơ sở đảo tạo quy định chỉ tiết thẩm quyền, điều kiện,
thủ tục chuyển chương trình, ngành đào tạo, chuyển nơi học, chuyển trường
hoặc chuyển hình thức học; việc công nhận kết quả học tập hoặc chuyển đổi
tín chỉ đã tích lũy đối cho sinh viên thuộc các trường hợp này.

Điều 17. Trao đối sinh viên và hợp tác trong đào tạo

1. Các cơ sở đào tạo xây dựng và ban hành quy định về việc công nhận
lẫn nhau về quy trình đào tạo, nội dung đào tạo và giá trị của tín chỉ làm căn
cứ cho phép sinh viên của cơ sở đào tạo này được học một số học phần †ại CƠ
sở đào tạo khác và ngược lại (sau đây gọi là trao đổi sinh viên).

2. Trên cơ sở đánh giá và công nhận lẫn nhau, sinh viên của cơ sở đảo
tạo này có thể đăng ký thực hiện học một số học phần tại cơ sở đào tạo khác,
nếu được hiệu trưởng của hai cơ sở đào tạo đồng ý với số lượng tín chỉ mà
sinh viên tích lũy tại cơ sở đào tạo khác (nếu có) không vượt quá 25% tổng
khối lượng của chương trình đào tạo.

3. Trong hợp tác đào tạo giữa các cơ sở đào tạo, việc đánh giá và công
nhận lẫn nhau số lượng tín chỉ mà sinh viên tích lũy tại cơ sở phối hợp đào tạo
khác không vượt quá 25% tổng khối lượng của chương trình đào tạo.

4. Quy chế của cơ sở đào tạo quy định về điều kiện trao đổi sinh viên,
hợp tác đào tạo, việc công nhận kết quả học tập và chuyển đổi tín chỉ cho sinh
viên khi thực hiện chương trình đào tạo và công khai trên trang thông tin điện
tử của cơ sở đào tạo.

Điều 18. Học cùng lúc hai chương trình

1. Đối với phương thức đảo tạo theo tín chỉ, sinh viên có thể đăng ký
học thêm các học phần của một chương trình khác, ngành khác khi điều kiện
của cơ sở đào tạo cho phép, nhưng chỉ được hướng các quyền lợi chính thức
và được xem xét công nhận tốt nghiệp chương trình thứ hai khi đã đăng ký
thành công học chương trình thứ hai theo quy định tại khoản 2 Điều này.

2. Sinh viên được đăng ký học chương trình thứ hai sớm nhất khi đã
được xếp trình độ năm thứ hai của chương trình thứ nhất. Tại thời điểm đăng
ký, sinh viên phải đáp ứng 01 trong 02 điều kiện sau và các điều kiện khác của cơ
sở đào tạo:


## Trang 19

17

a) Học lực tính theo điểm trung bình tích lũy xếp loại khá trở lên và đáp ứng
ngưỡng bảo đám chất lượng của chương trình thứ hai trong năm tuyển sinh;

b) Học lực tính theo điểm trung bình tích lũy xếp loại trung bình và đáp
ứng điều kiện trúng tuyển của chương trình thứ hai trong năm tuyển sinh.

3. Trong quá trình sinh viên học cùng lúc hai chương trình, nếu điểm
trung bình tích luỹ của chương trình thứ nhất đạt đưới điểm trung bình hoặc
thuộc diện cảnh báo kết quả học tập thì phải đừng học chương trình thứ hai ở
học kỳ tiếp theo; sinh viên sẽ bị loại khỏi danh sách đã đăng ký học chương
trình thứ hai.

4. Thời gian tối đa được phép học đối với sinh viên học củng lúc hai
chương trình là thời gian tối đa qủy định cho chương trình thứ nhất, quy định
tại khoản 5 Điều 2 của Quy chế này. Khi học chương trình thứ hai, sinh viên
được công nhận kết quả của những học phần có nội dung và khối lượng kiến
thức tương đương có trong chương trình thứ nhất.

5. Sinh viên chỉ được xét tốt nghiệp chương trình thứ hai, nếu có đủ
điều kiện tốt nghiệp ở chương trình thứ nhất và đã đăng kí muộn nhất 02 năm
trước thời điểm xét tốt nghiệp chương trình thứ hai.

6. Cơ sở đào tạo chỉ tổ chức đào tạo chương trình thứ hai cho sinh viên
khi đáp ứng các yêu cầu báo đảm chất lượng về chỉ tiêu tuyển sinh, năng lực
đào tạo; đồng thời có quy định chỉ tiết về quy trình, thủ tục, điều kiện đăng ký
học và cấp bằng tốt nghiệp chương trình thứ hai.

Điều 19. Học liên thông đối với người có văn bằng khác

1. Người đã tốt nghiệp các trình độ đào tạo của giáo dục nghề nghiệp
được dự tuyên và học liên thông lên trình độ đại học theo quy định hiện bành
của Chính phủ, Thủ tướng Chính phủ và quy chế của cơ sở đào tạo.

2. Người đã tốt nghiệp đại học được dự tuyển và học liên thông để nhận
thêm một bằng tốt nghiệp đại học của một ngành đào tạo khác, khi cơ sở đào
tạo đã áp dụng thống nhất phương thức đào tạo theo tín chỉ (riêng các ngành
an ninh, quốc phòng thực hiện theo quy định của cơ sở đào tạo) và đã tuyển
sinh được tối thiểu 03 khóa theo ngành đào tạo và hình thức đào tạo mà người
học lựa chọn.

3. Người học liên thông thực hiện chương trình đảo tạo và đăng ký học
tập theo kế hoạch chung như các sinh viên khác cùng hình thức đào tạo. Trên
cơ sở công nhận và chuyên đổi tín chỉ, sinh viên được miễn trừ các học phần


## Trang 20

18

tương ứng với những khối lượng học tập đã tích lũy theo quy định tại Điều 13
của Quy chế này.

4. Quy chế đào tạo của cơ sở đào tạo quy định chỉ tiết điều kiện, thủ tục
tiếp nhận học liên thông: việc công nhận, chuyển đổi tín chỉ và miễn trừ học
phần cho sinh viên liên thông dựa trên nguyên tắc công bằng, minh bạch với
mọi đối tượng, bảo đâm chặt chẽ yêu cầu về chất lượng, áp dụng chuẩn đầu ra
chung như đối với những sinh viên khác.

Điều 20. Xử lý vi phạm đối với sinh viên

1. Sinh viên có gian lận trong thi, kiểm tra, đánh giá kết quả học tập sẽ
bị xử lý kỷ luật đối với từng học phần đã vi phạm theo các quy định của Quy
chế thi tốt nghiệp Trung học phổ thông hiện hành do Bộ Giáo dục và Đảo tạo
ban hành, trừ trường hợp quy định tại khoản 2 Điều này.

2. Sinh viên thi hộ hoặc nhờ người thi hộ đều bị kỷ luật ở mức đình chỉ
học tập 01 năm đối với trường hợp vỉ phạm lần thứ nhất và buộc thôi học đối
với trường hợp vi phạm lần thứ hai.

3. Người học sử dụng hồ sơ, văn bằng, chứng chỉ giả làm điều kiện
trúng tuyển hoặc điều kiện tốt nghiệp sẽ bị buộc thôi học; văn bằng tốt nghiệp
nếu đã được cấp sẽ bị thu hồi, huỷ bỏ.

Chương V
TỎ CHỨC THỰC HIỆN
Điều 21. Xây dựng và thực hiện quy chế của cơ sở đào tạo

1. Căn cứ Quy chế này và các quy định hiện hành khác có liên quan,
hiệu trưởng cơ sở đào tạo có trách nhiệm:

a) Chỉ đạo xây dựng, ban hành và tổ chức thực hiện quy chế đảo tạo của
cơ sở đào tạo trên cơ sở tư vấn của hội đồng khoa học và đào tạo và các quy
định quản lý nội bộ; cụ thể hóa và có thể yêu cầu cao hơn nhưng không trái
với các quy định của Quy chế này;

b) Ban hành các quyết định tổ chức đào tạo chính quy, vừa làm vừa học,
liên kết đào tạo, đào tạo liên thông (nếu có) bảo đảm đầy đủ các yêu cầu theo
Quy chế này: trong đó phải ghi rõ tên ngành, hình thức đảo tạo, đối tượng, chỉ
tiêu và phương thức tuyển sinh, địa điểm đảo tạo, cơ sở phối hợp đào tạo và
các thông tin khác có liên quan;


## Trang 21

19

c) Tổ chức phổ biến, hướng dẫn cho sinh viên quy chế của cơ sở đào tạo
và các quy định liên quan đến quá trình học tập, các quy định về nghĩa vụ và
quyên lợi của sinh viên ngay đầu khóa học;

đ) Tổ chức kiểm tra, thanh tra nội bộ việc thực hiện kế hoạch, chương
trình, quy chế của cơ sở đào tạo và các nhiệm vụ khác liên quan đến đào tạo;
chịu sự kiểm tra, thanh tra, giám sát của Bộ Giáo dục và Đào tạo và các cơ
quan có thẩm quyển theo các quy định hiện hành.

2. Cơ sở đào tạo thực hiện giải trình theo quy định tại khoản 4 Điều 13
Nghị định số 99/2019/NĐ-CP ngày 30 tháng 12 năm 2019 của Chính phủ quy -
định chỉ tiết và hướng dẫn thi hành một số điều của Luật sửa đổi bổ sung một
số điều của Luật Giáo dục đại học và các quy định khác của pháp luật có liên quan.

Điều 22. Chế độ báo cáo, lưu trữ, công khai thông tin

1. Trước ngày 31 tháng 12 hằng năm:

a) Cơ sở đảo tạo báo cáo Bộ Giáo dục và Đào tạo và cơ quan quản lý
trực tiếp về số liệu sinh viên tuyển mới, tốt nghiệp, thôi học và đang học trong
năm, dự kiến tốt nghiệp trong năm sau, tốt nghiệp đã có việc làm trong thời
gian 12 tháng; phân loại theo đối tượng đầu vào, ngành đào tạo, khóa đào tạo
và hình thức đào tạo;

b) Cơ sở đào tạo báo cáo Ủy ban nhân dân cấp tỉnh nơi liên kết đào tạo
về tình hình tuyển sinh và đào tạo tại địa phương.

2. Cơ sở đào tạo có trách nhiệm lưu trữ, bảo quản an toàn các tài liệu
liên quan tới công tác đào tạo theo các quy định đo Bộ Giáo dục và Đào tạo ban hành.

a) Quyết định trúng tuyển, bảng điểm gốc, quyết định công nhận tốt
nghiệp, số gốc cấp phát bằng tốt nghiệp cho sinh viên là tài liệu lưu trữ được
bảo quản vĩnh viễn tại cơ sở đảo tạo;

b) Tài liệu khác liên quan đến tuyển sinh, đào tạo được lưu trữ, bảo
quản trong suốt quá trình đào tạo;

c) Việc tiêu hủy tài liệu liên quan tuyển sinh, đào tạo hết thời gian lưu
trữ được thực hiện theo quy định hiện hành của Nhà nước.

3. Cơ sở đào tạo công khai trên trang thông tin điện tử của mình chậm
nhất 45 ngày trước khi tổ chức đào tạo:

a) Quy chế của cơ sở đào tạo và các quy định quản lý đào tạo có liên quan;

b) Quyết định mở ngành và các quyết định nêu tại điểm b khoản 1Điều
21 đối với chương trình sẽ tổ chức đào tạo;


## Trang 22

20
c) Các điều kiện bảo đảm chất lượng theo quy định hiện hành của Bộ
Giáo dục và Đào tạo;

đ) Các minh chứng về việc các chương trình đào tạo đáp ứng chuẩn
chương trình đào tạo do Bộ Giáo dục và Đào tạo ban hành;

đ) Thông báo tuyến sinh theo quy chế tuyển sinh hiện hành;

©) Các minh chứng về việc đáp ứng các yêu cầu tối thiểu đối với liên kết
đào tạo vừa làm vừa học theo quy định tại khoản 2 và khoản 3 Điều 5 của Quy
chế này.

KT. BỘ TRƯỞNG

Hoàng Minh Sơn
