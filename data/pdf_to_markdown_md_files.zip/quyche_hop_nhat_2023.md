# quyche_hop_nhat_2023

> Nguồn: chuyển đổi từ PDF; văn bản được trích xuất trực tiếp từ lớp văn bản của PDF.


## Trang 1

QUY CHẾ ĐÀO TẠO TRÌNH ĐỘ ĐẠI HỌC
TẠI TRƯỜNG ĐẠI HỌC CÔNG NGHIỆP HÀ NỘI
(Hợp nhất quy chế đào tạo ban hành theo quyết định 744/QĐ-ĐHCN ngày 19 tháng 08
năm 2021 và quyết định sửa đổi một số điều của quy chế 744 ban hành theo Quyết định
666/QĐ-ĐHCN ngày 01 tháng 06 năm 2023)

Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng
 1. Quy chế này quy định chung về tổ chức và quản lý đào tạo trình độ đại
học, bao gồm: Chương trình đào tạo và thời gian học tập; hình thức và phương
thức tổ chức đào tạo; lập kế hoạch và tổ chức giảng dạy; đánh giá kết quả học tập
và cấp bằng tốt nghiệp; những quy định khác đối với sinh viên.
 2. Quy chế này áp dụng đối với các Khoa, Trung tâm, Trường (sau đây gọi
chung là Khoa) thuộc, trực thuộc Trường Đại học Công nghiệp Hà Nội (sau đây
gọi là Trường hoặc Nhà trường) có nhiệm vụ đào tạo trình độ đại học, các tổ chức,
cá nhân liên quan trong đào tạo theo hình thức chính quy và hình thức vừa làm
vừa học. Các chương trình đào tạo do cơ sở giáo dục nước ngoài cấp bằng bao
gồm cả các chương trình liên kết đào tạo được áp dụng quy chế này hoặc quy định
của cơ sở đào tạo cấp bằng theo thỏa thuận liên kết, hợp tác giữa các bên nhưng
không trái với những quy định của quy chế này.
3. Quy chế này là căn cứ để Hiệu trưởng Nhà trường (sau đây gọi Hiệu
trưởng) xây dựng và ban hành các văn bản quy định, hướng dẫn cụ thể về tổ chức
và quản lý đào tạo trình độ đại học và cả trình độ đào tạo đối với một số ngành
đào tạo chuyên sâu đặc thù quy định tại điểm a khoản 1 Điều 14 Nghị định số
99/2019/NĐ-CP ngày 30 tháng 12 năm 2019 của Chính phủ quy định chi tiết và
hướng dẫn thi hành một số điều của Luật sửa đổi, bổ sung một số điều của Luật
Giáo dục đại học.
Điều 2. Chương trình đào tạo và thời gian học tập
1. Chương trình đào tạo được xây dựng theo đơn vị tín chỉ, cấu trúc từ các
môn học hoặc học phần (sau đây gọi chung là học phần), trong đó phải có đủ các
học phần bắt buộc và đáp ứng chuẩn chương trình đào tạo theo quy định hiện hành
của Nhà trường và của Bộ Giáo dục và Đào tạo. Trong trường hợp đào tạo song
ngành hoặc ngành chính - ngành phụ, chương trình đào tạo phải thể hiện rõ khối
lượng học tập chung và riêng theo từng ngành.
2. Nội dung, chuẩn đầu ra của chương trình đào tạo áp dụng chung đối với
các hình thức, phương thức tổ chức đào tạo và đối tượng người học khác nhau.


## Trang 2

Đối với người đã tốt nghiệp trình độ khác hoặc ngành khác, khối lượng học tập
thực tế được xác định trên cơ sở công nhận, hoặc chuyển đổi tín chỉ đã tích lũy và
miễn trừ học phần trong chương trình đào tạo trước.
3. Chương trình đào tạo phải được công khai đối với người học trước khi
tuyển sinh và khi bắt đầu khóa học; những thay đổi, điều chỉnh liên quan đến
chương trình đào tạo được thực hiện theo quy định hiện hành và công bố trước
khi áp dụng, không gây tác động bất lợi cho sinh viên.
4. Đối với mỗi hình thức đào tạo, chương trình đào tạo cần cung cấp kế
hoạch học tập chuẩn toàn khoá để định hướng cho sinh viên:
a) Thời gian theo kế hoạch học tập chuẩn toàn khoá đối với hình thức đào
tạo chính quy phải phù hợp với thời gian quy định trong Khung cơ cấu hệ thống
giáo dục quốc dân, đồng thời đảm bảo đa số sinh viên hoàn thành chương trình
đào tạo;
b) Thời gian theo kế hoạch học tập chuẩn toàn khoá đối với hình thức đào
tạo vừa làm vừa học dài hơn tối thiểu 20% so với hình thức đào tạo chính quy của
cùng chương trình đào tạo.
5. Thời gian tối đa để sinh viên hoàn thành khoá học được quy định như sau:
a) Sinh viên tuyển sinh, đào tạo trước ngày 3 tháng 5 năm 2021, thời gian
tối đa để hoàn thành khóa học bằng 02 lần thời gian theo kế hoạch học tập chuẩn
toàn khoá đối với mỗi hình thức đào tạo; không hạn chế thời gian tối đa hoàn
thành khóa học đối với sinh viên thuộc diện được hưởng chính sách ưu tiên theo
quy định tại Quy chế tuyển sinh đại học chính quy;
b) Sinh viên tuyển sinh, đào tạo từ ngày 3 tháng 5 năm 2021 trở đi, thời
gian tối đa để hoàn thành khóa học không vượt quá 06 năm tính từ ngày nhập học;
sinh viên được Nhà trường cử đi trao đổi, thực tập ở nước ngoài thời gian tối đa
để hoàn thành khóa học do Hiệu trưởng quyết định nhưng không vượt quá 02 lần
thời gian theo kế hoạch học tập chuẩn toàn khoá;
c) Sinh viên học liên thông đã được miễn trừ khối lượng tín chỉ tích lũy,
thời gian tối đa để sinh viên hoàn thành khóa học được xác định trên cơ sở thời
gian theo kế hoạch học tập chuẩn toàn khoá giảm tương ứng với khối lượng được
miễn trừ;
d) Không tính vào thời gian hoàn thành khóa học đối với những trường hợp
khi đang trong thời gian: bị ốm, thai sản hoặc tai nạn phải điều trị được cơ quan
có thẩm quyền theo quy định của Bộ Y tế xác nhận; được điều động vào lực lượng
vũ trang theo quy định của Nhà nước; được cơ quan có thẩm quyền điều động,


## Trang 3

đại diện quốc gia tham dự các kỳ thi, giải đấu quốc tế.
Điều 3. Phương thức tổ chức đào tạo
1. Đào tạo theo tín chỉ:
a) Là phương thức tổ chức đào tạo theo từng lớp học phần, cho phép sinh
viên tích lũy tín chỉ của từng học phần và thực hiện chương trình đào tạo theo kế
hoạch học tập của cá nhân, phù hợp với kế hoạch giảng dạy của Nhà trường;
b) Sinh viên không đạt một học phần bắt buộc sẽ phải học lại học phần đó
hoặc học một học phần tương đương theo quy định trong chương trình đào tạo,
hoặc học một học phần thay thế nếu học phần đó không còn được giảng dạy;
c) Sinh viên không đạt một học phần tự chọn sẽ phải học lại học phần đó
hoặc có thể chọn học một học phần tự chọn khác trong cùng nhóm tự chọn hoặc
đăng ký học phần tương đương, học phần thay thế theo quy định trong chương
trình đào tạo.
2. Nhà trường áp dụng phương thức đào tạo theo tín chỉ cho tất cả các khóa
và hình thức đào tạo.
Điều 4. Hình thức đào tạo
1. Đào tạo chính quy:
a) Các hoạt động giảng dạy được thực hiện tại các cơ sở đào tạo của Nhà
trường, riêng những hoạt động thực hành, thực tập, trải nghiệm thực tế và giảng
dạy trực tuyến có thể thực hiện ngoài cơ sở đào tạo của Nhà trường;
b) Thời gian tổ chức hoạt động giảng dạy trong khoảng từ 07 giờ đến 21
giờ các ngày trong tuần từ thứ hai đến thứ bảy; thời gian tổ chức những hoạt động
đặc thù của chương trình đào tạo (thực hành, thực tập, trực tuyến, ngoại khóa, lớp
mở theo yêu cầu của người học, …) được thực hiện theo quy định của Nhà trường.
2. Đào tạo vừa làm vừa học:
a) Các hoạt động giảng dạy được thực hiện tại Nhà trường hoặc tại cơ sở
phối hợp đào tạo theo quy định liên kết đào tạo tại Điều 5 của Quy chế này, riêng
những hoạt động thực hành, thực tập, trải nghiệm thực tế và giảng dạy trực tuyến
có thể thực hiện ngoài Nhà trường, cơ sở phối hợp đào tạo;
b) Thời gian tổ chức hoạt động giảng dạy linh hoạt trong ngày và trong tuần.
3. Đối với các ngành đào tạo ưu tiên phục vụ nguồn nhân lực phát triển kinh
tế - xã hội trong từng giai đoạn, Nhà trường có thể thực hiện các hình thức đào
tạo phù hợp theo hướng dẫn của Bộ Giáo dục và Đào tạo.
Điều 5. Liên kết đào tạo


## Trang 4

1. Liên kết đào tạo chỉ thực hiện đối với hình thức vừa làm vừa học theo
quy định tại khoản 22 Điều 1 Luật sửa đổi, bổ sung một số điều của Luật Giáo
dục đại học và theo quy định tại khoản 2, khoản 3 Điều này.
2. Các yêu cầu tối thiểu đối với cơ sở chủ trì đào tạo:
a) Đã được công nhận đạt tiêu chuẩn chất lượng cơ sở giáo dục đại học bởi
tổ chức kiểm định chất lượng giáo dục hợp pháp và còn hiệu lực theo quy định;
b) Chương trình đào tạo dự kiến liên kết đào tạo đã được tổ chức thực hiện
tối thiểu 03 khoá liên tục theo hình thức chính quy; từ khóa tuyển sinh năm 2024
yêu cầu chương trình đào tạo đã được công nhận đạt chuẩn chất lượng theo quy
định hiện hành;
c) Bảo đảm đội ngũ giảng viên cơ hữu giảng dạy tối thiểu 70% nội dung,
khối lượng chương trình đào tạo;
d) Đã ban hành quy định về liên kết và đã thẩm định các điều kiện bảo đảm
chất lượng của cơ sở phối hợp đào tạo.
3. Các yêu cầu tối thiểu của cơ sở phối hợp đào tạo:
a) Đáp ứng các yêu cầu về môi trường sư phạm, cơ sở vật chất, thiết bị, thư
viện và cán bộ quản lý theo yêu cầu của chương trình đào tạo;
b) Đã có báo cáo tự đánh giá chất lượng cơ sở giáo dục gửi về cơ quan nhà
nước có thẩm quyền theo quy định; từ khóa tuyển sinh năm 2024 yêu cầu đã được
công nhận đạt tiêu chuẩn chất lượng cơ sở giáo dục theo quy định hiện hành;
c) Cơ sở phối hợp đào tạo chỉ được tham gia giảng dạy tối đa 30% nội dung
chương trình đào tạo nếu Khoa được Cơ sở chủ trì đào tạo giao quản lý chương
trình đào tạo có yêu cầu, đồng thời phải bố trí cho giảng viên tham gia giảng dạy
sinh hoạt chuyên môn với các Khoa được giao quản lý học phần của Cơ sở chủ trì
đào tạo.
4. Trách nhiệm của các bên tham gia liên kết đào tạo:
a) Cơ sở chủ trì đào tạo và cơ sở phối hợp đào tạo chịu trách nhiệm ký kết
hợp đồng liên kết đào tạo, thỏa thuận cụ thể về quyền và trách nhiệm của các bên
trong việc phối hợp tổ chức thực hiện, quản lý quá trình dạy học bảo đảm chất
lượng đào tạo và thực hiện nội dung đã thỏa thuận phù hợp với các quy định của
Quy chế này và các quy định pháp luật khác có liên quan;
b) Cơ sở chủ trì đào tạo chịu trách nhiệm quản lý chất lượng đào tạo; báo
cáo hoạt động liên kết đào tạo với Ủy ban nhân dân cấp tỉnh nơi liên kết đào tạo
trước khi tổ chức tuyển sinh; nếu cơ sở phối hợp đào tạo không đáp ứng được các
yêu cầu về bảo đảm chất lượng theo quy định của học phần hoặc của chương trình


## Trang 5

đào tạo thì phải chuyển sinh viên về cơ sở chủ trì liên kết để tiếp tục đào tạo theo
quy định và bảo đảm quyền lợi cho sinh viên;
c) Cơ sở phối hợp đào tạo có trách nhiệm cùng cơ sở chủ trì đào tạo bảo
đảm đủ điều kiện cơ sở vật chất thực hiện đào tạo; tham gia quản lý, giảng dạy,
theo thoả thuận giữa hai bên;
d) Cơ sở chủ trì đào tạo, cơ sở phối hợp đào tạo chịu trách nhiệm trước pháp
luật về việc thực hiện hợp đồng liên kết đào tạo; thực hiện các quy chế về tuyển
sinh, đào tạo; bảo đảm quyền lợi chính đáng cho giảng viên, sinh viên trong suốt
quá trình thực hiện hoạt động đào tạo.
5. Quy định về điều kiện, quy trình thực hiện liên kết đào tạo của Nhà trường:
a) Nhà trường chỉ chủ trì liên kết đào tạo theo hình thức vừa làm vừa học
với cơ sở giáo dục đáp ứng yêu cầu tối thiểu ở khoản 3 điều này;
b) Chỉ tiêu tuyển sinh dành cho các chương trình liên kết đào tạo nằm trong
tổng chỉ tiêu tuyển sinh vừa làm vừa học hàng năm của Nhà trường;
c) Trung tâm Đào tạo thường xuyên trình Hiệu trưởng hồ sơ đăng ký thực
hiện liên kết đào tạo gồm có: Đề xuất thực hiện liên kết đào tạo; Hồ sơ minh chứng
việc đáp ứng yêu cầu tối thiểu ở khoản 2, khoản 3 điều này; Danh sách giảng viên
cơ hữu tham gia giảng dạy và cán bộ quản lý; Danh sách giảng viên tham gia
giảng dạy (nếu có), danh mục cơ sở vật chất tại cơ sở phối hợp đào tạo để xem
xét thẩm định các điều kiện đảm bảo chất lượng đào tạo;
d) Trong vòng 30 ngày kể từ ngày nhận Hồ sơ đăng ký thực hiện liên kết
đào tạo, Hiệu trưởng ra quyết định thành lập Tổ thẩm định các điều kiện đảm bảo
chất lượng đào tạo của cơ sở phối hợp đào tạo. Tổ thẩm định gồm 3 đến 5 thành
viên, gồm đại diện của Phòng Đào tạo; Khoa quản lý Chương trình đào tạo; Trung
tâm Đào tạo thường xuyên và các đơn vị liên quan khác;
e) Tổ thẩm định tiến hành thẩm định các điều kiện đảm bảo chất lượng đào
tạo tại cơ sở phối hợp đào tạo theo quy định tại khoản 3 Điều này và lập biên bản
thẩm định trình Hiệu trưởng ra quyết định thực hiện liên kết đào tạo;
f) Hiệu trưởng quyết định cho phép thực hiện liên kết đào tạo khi đủ các
điều kiện quy định tại các khoản 1, 2, 3, 4, 5 Điều này.
Điều 6. Kế hoạch giảng dạy và học tập
1. Kế hoạch giảng dạy và học tập (còn được gọi là Kế hoạch dạy học) chi
tiết hóa việc tổ chức thực hiện các chương trình đào tạo theo năm học, học kỳ,
phù hợp với hình thức đào tạo và phương thức tổ chức đào tạo.


## Trang 6

2. Trước khi bắt đầu mỗi năm học, Nhà trường công bố kế hoạch năm học
thể hiện những mốc thời gian chính của các hoạt động đào tạo trong năm học cho
tất cả các hình thức, chương trình đào tạo. Một năm học có 02 học kỳ chính, mỗi
học kỳ chính có từ 14 đến 16 tuần lên lớp và 02 tuần thi. Ngoài học kỳ chính, mỗi
năm học Nhà trường có thể tổ chức thêm từ 01 đến 02 học kỳ phụ, mỗi học kỳ
phụ có từ 05 đến 08 tuần lên lớp và 01 tuần thi. Học kỳ phụ để tạo điều kiện cho
sinh viên được học lại, học cải thiện điểm, học bù hoặc học vượt.
3. Kế hoạch học kỳ bao gồm: kế hoạch đăng ký khối lượng học tập, thời
khóa biểu, hình thức dạy-học (trực tiếp, trực tuyến hoặc kết hợp trực tiếp và trực
tuyến theo quy định tại Hướng dẫn tổ chức dạy học của học phần), thời gian học,
thời gian thi kết thúc học phần của các lớp học phần dự kiến mở trong học kỳ cho
các khoá học, chương trình đào tạo, hình thức dạy-học do Hiệu trưởng quyết định.
Kế hoạch học kỳ được công bố trước thời điểm đăng ký học tập từ 01 đến 03 tuần
để thuận tiện cho sinh viên xây dựng kế hoạch học tập và đăng ký học tập..1
4. Thời khoá biểu thể hiện thời gian, địa điểm, hoạt động dạy và học của
từng lớp thuộc các khoá học, hình thức và chương trình đào tạo. Thời khóa biểu
của các lớp học phần bình thường được bố trí đều trong các tuần của học kỳ. Trong
trường hợp cần thiết phải xếp lịch học tập trung thời gian, số giờ giảng lý thuyết
của một học phần không vượt quá 15 giờ/tuần và 4 giờ/ngày; số giờ thực hiện
những hoạt động đặc thù của chương trình đào tạo (thực hành, thực tập, trực tuyến,
ngoại khóa, lớp mở theo yêu cầu của người học, …) được thực hiện theo quy định
của Nhà trường.
5. Phòng Đào tạo dự kiến số lượng lớp học phần cho mỗi học phần, thời
khóa biểu cho các lớp học phần trong từng học kỳ gửi các Khoa quản lý học phần
để thống nhất kế hoạch và phân công giảng viên giảng dạy trên Hệ thống quản lý
đào tạo trước khi tổ chức cho sinh viên đăng ký học tập.
Điều 7. Tổ chức đăng ký học tập
1. Trước khi bắt đầu đợt đăng ký học tập ở mỗi học kỳ, các Khoa quản lý
sinh viên hướng dẫn cho sinh viên đăng ký học tập trên Hệ thống quản lý đào tạo
của Nhà trường.
2. Sinh viên phải đăng ký lớp của các học phần dự định sẽ học trong học
kỳ, gồm: những học phần mới, một số học phần chưa đạt (để học lại) và một số
học phần đã đạt (để cải thiện điểm, nếu có) căn cứ danh sách học phần được mở

1 Sửa đổi, bổ sung tại Quyết định số 666/QĐ-ĐHCN ngày 01/6/2023


## Trang 7

và điều kiện đăng ký của mỗi học phần.
3. Trong mỗi học kỳ có hai đợt đăng ký: Đợt đăng ký chính và đợt đăng ký
bổ sung.
a) Đợt đăng ký chính được thực hiện trước thời điểm bắt đầu học kỳ từ 03
đến 04 tuần cho tất cả sinh viên muốn đăng ký hoặc hủy đăng ký vào các lớp học
phần được tổ chức trong học kỳ. Tại một thời điểm bất kỳ trong đợt đăng ký chính,
sinh viên được phép đăng ký tối đa 33 tín chỉ nhưng trước khi kết thúc đợt đăng
ký chính sinh viên phải điều chỉnh để khối lượng học tập phù hợp quy định tại
khoản 5 Điều này; Trường hợp số tín chỉ đăng ký vượt quá khối lượng học tập
quy định tại khoản 5 Điều này nếu sinh viên không điều chỉnh, hệ thống sẽ tự
động rút ngẫu nhiên các học phần để khối lượng học tập của sinh viên phù hợp
quy định;
b) Đợt đăng ký bổ sung được thực hiện trước thời điểm bắt đầu học kỳ từ
01 đến 02 tuần cho những sinh viên muốn đăng ký bổ sung vào các lớp học phần
đã được Nhà trường thông báo mở;
c) Trong thời gian đăng ký học tập, sinh viên chỉ được phép đăng ký tối đa
vào 01 lớp học phần được tổ chức cho mỗi học phần;
d) Ngoài thời gian trên, nếu có sinh viên chuyển trường, chuyển
ngành/chương trình đào tạo, học tiếp sau thời gian nghỉ học tạm thời muốn đăng
ký bổ sung vào các lớp học phần đã mở hoặc sinh viên có nguyện vọng học đổi
từ học phần đã đăng ký thành công sang học phần khác thì Khoa quản lý sinh viên
lập danh sách theo mẫu và gửi về Phòng Đào tạo tổng hợp, báo cáo Hiệu trưởng
quyết định.
4. Hai học kỳ đầu tiên của năm thứ nhất sinh viên được Nhà trường sắp xếp
học theo tiến độ đào tạo chuẩn. Từ học kỳ thứ 3 trở đi sinh viên được tư vấn để tự
chọn và tự đăng ký khối lượng học tập.
5. Khối lượng học tập mà mỗi sinh viên phải đăng ký trong mỗi học kỳ
chính không tính các học phần ngoài khung chương trình đào tạo, các học phần
Giáo dục thể chất, Giáo dục quốc phòng-an ninh, được quy định như sau:
a) Khối lượng học tập tối thiểu 10 tín chỉ cho mỗi học kỳ; không quy định
khối lượng học tập tối thiểu nếu sinh viên còn nợ khối lượng học tập dưới mức
tối thiểu hoặc trong học kỳ không có lớp học phần để sinh viên đăng ký đủ khối
lượng học tập tối thiểu quy định ở trên;
b) Khối lượng học tập tối đa 27 tín chỉ cho mỗi học kỳ;
c) Các trường hợp đặc biệt do Hiệu trưởng quyết định.


## Trang 8

6. Việc đăng ký các học phần sẽ học cho từng học kỳ phải bảo đảm điều
kiện tiên quyết của từng học phần và trình tự học tập của mỗi chương trình cụ thể.
7. Phòng Đào tạo tổ chức cho sinh viên đăng ký khối lượng học tập ở mỗi
học kỳ. Dữ liệu đăng ký học tập của sinh viên được lưu trữ trên Hệ thống quản lý
đào tạo của Nhà trường, bao gồm các thông tin tối thiểu như: thời gian đăng ký,
mã lớp học phần đã đăng ký hoặc hủy đăng ký, số tín chỉ của học phần, học kỳ
mở lớp, tài khoản thực hiện đăng ký. Sinh viên đăng ký thành công vào lớp học
phần được thành lập phải đóng học phí theo quy định.
8. Những sinh viên đăng ký không đủ khối lượng học tập tối thiểu ở học kỳ
chính nào sẽ được Trưởng khoa xem xét và đề xuất Hiệu trưởng quyết định cho
học tiếp hoặc tạm dừng học ở học kỳ đó. Việc cho học tiếp hay tạm dừng học đối
với sinh viên không đủ khối lượng học tập tối thiểu ở học kỳ phải được thông báo
đến sinh viên trong tuần đầu tiên của học kỳ.
9. Sau khi đăng ký thành công vào lớp học phần, sinh viên không đi học
được coi là tự ý bỏ học, phải nhận điểm F là điểm học phần và phải đóng học phí
theo quy định.
10. Rút bớt khỏi lớp học phần đã đăng ký.
Từ tuần thứ 03 đến hết tuần thứ 08 của học kỳ chính hoặc từ tuần thứ 02
đến hết tuần thứ 04 của học kỳ phụ, sinh viên không vi phạm điểm a khoản 5 Điều
này được phép rút khỏi lớp học phần đã đăng ký trên Hệ thống quản lý đào tạo
của Nhà trường nhưng vẫn phải đóng học phí. Trường hợp đặc biệt do Hiệu trưởng
quyết định.2
Điều 8. Tổ chức giảng dạy và học tập
1. Yêu cầu về tổ chức giảng dạy và học tập:
a) Phát huy năng lực chuyên môn và trách nhiệm nghề nghiệp của đội ngũ
giảng viên, phù hợp với quy định về chế độ làm việc của giảng viên;
b) Phát huy vai trò chủ động đồng thời đề cao trách nhiệm của sinh viên,
tạo điều kiện và động lực để sinh viên nỗ lực học tập; giữ vững kỷ cương học
đường, nâng cao chất lượng và hiệu quả đào tạo;
c) Có cơ chế thanh tra, giám sát nội bộ và có hệ thống cải tiến chất lượng
dựa trên thu thập, đánh giá ý kiến phản hồi của người học.
2. Dạy và học trực tuyến:
a) Nhà trường tổ chức các lớp học phương thức trực tuyến hoặc kết hợp

2 Sửa đổi, bổ sung quy định về thời gian rút học phần tại Quyết định số 666/QĐ-ĐHCN ngày 01/6/2023


## Trang 9

trực tiếp với trực tuyến khi đáp ứng các quy định hiện hành về ứng dụng công
nghệ thông tin trong quản lý và tổ chức đào tạo qua mạng; có các giải pháp bảo
đảm chất lượng và minh chứng về chất lượng tổ chức lớp học phương thức trực
tuyến không thấp hơn chất lượng lớp học phương thức trực tiếp;
b) Đối với đào tạo theo hình thức chính quy và vừa làm vừa học, tối đa 30%
tổng khối lượng của chương trình đào tạo được thực hiện bằng phương thức trực
tuyến. Trong trường hợp thiên tai, dịch bệnh phức tạp và các trường hợp bất khả
kháng khác, Nhà trường thực hiện theo hướng dẫn của Bộ Giáo dục và Đào tạo.
3. Tổ chức lớp học:
a) Lớp học phần được tổ chức cho từng học phần. Trước khi tổ chức cho
sinh viên đăng ký học tập mỗi lớp học phần phải có tối thiểu các thông tin về: mã
lớp học phần, mã học phần, tên học phần, số tín chỉ của học phần, thời gian học
tập, địa điểm học tập, giảng viên, đồng giảng, trợ giảng (nếu có);
b) Trưởng khoa phân công giảng viên, đồng giảng, trợ giảng (nếu có) mỗi
lớp học phần theo đúng chuyên môn, nghiệp vụ;
c) Lớp học phần được thành lập khi có số lượng sinh viên tối thiểu đã đăng
ký vào lớp như sau:
- 60 sinh viên đối với các học phần giáo dục đại cương, 50 sinh viên đối với
những học phần cơ sở ngành và 40 sinh viên đối với những học phần chuyên
ngành; 20 sinh viên đối với các học phần chỉ có nội dung thực hành, thí nghiệm,
học phần ngoại ngữ hoặc học phần chuyên môn giảng dạy bằng ngoại ngữ;
- Nếu số lượng sinh viên đăng ký thấp hơn số lượng tối thiểu quy định thì
lớp học sẽ không được tổ chức; sinh viên phải đăng ký chuyển sang học những
học phần khác, nếu chưa đảm bảo đủ quy định về khối lượng học tập tối thiểu
trong học kỳ;
- Trường hợp đặc biệt do Hiệu trưởng quyết định.
d) Lớp học phần Thực tập, Đồ án/Dự án; lớp học phần Đồ án/Khóa luận tốt
nghiệp không quy định số lượng sinh viên tối thiểu.
4. Lấy ý kiến phản hồi của người học về các điều kiện bảo đảm chất lượng,
hiệu quả học tập:
a) Nhà trường tổ chức lấy ý kiến phản hồi của người học về các rút bảo đảm
chất lượng, hiệu quả học tập đối với lớp học phần thông qua Hệ thống quản lý đào
tạo của Nhà trường;
b) Thời điểm lấy ý kiến: Sau khi đánh giá kết thúc học phần;


## Trang 10

c) Kết quả lấy ý kiến phản hồi của người học, bao gồm nội dung, mức độ,
được công khai tới cán bộ, viên chức, giảng viên và sinh viên liên quan trên Hệ
thống quản lý đào tạo của Nhà trường.
5. Trách nhiệm và quyền hạn của giảng viên được phân công giảng dạy các
lớp học phần:
a) Được phân công giảng dạy theo đúng chuyên môn, nghiệp vụ; được
quyền đề nghị phân công giảng viên dạy thay, đề nghị đổi giờ trong trường hợp
bất khả kháng không thể tham gia giảng dạy được;
b) Thông báo cho sinh viên về mục tiêu, chuẩn đầu ra, nội dung, phương
pháp (phương thức), kế hoạch dạy học và đánh giá kết quả học tập ngay trong
buổi học đầu tiên của lớp học phần;
c) Giảng dạy, kiểm tra, đánh giá kết quả học tập một cách khách quan theo
đúng đề cương chi tiết học phần, hướng dẫn dạy học, hướng dẫn đánh giá kết quả
học tập, thời khóa biểu và lịch giảng dạy đã được phê duyệt. Công bố kết quả học
tập cho sinh viên và nhập kết quả học tập lên Hệ thống quản lý đào tạo của Nhà
trường chậm nhất là 07 ngày làm việc sau khi thực hiện mỗi bài kiểm tra, đánh giá;
d) Hướng dẫn sinh viên xây dựng kế hoạch tự học tập, phương pháp học
tập, nghiên cứu phù hợp với đặc thù của học phần; Dành tối thiểu 60 phút/Giờ
giảng lý thuyết và 30 phút/Giờ hướng dẫn thực hành hoặc thí nghiệm để hướng
dẫn, giải đáp thắc mắc trong quá trình sinh viên tự học, chuẩn bị bài và làm bài
tập thông qua:
- Tư vấn trực tiếp tại văn phòng bộ môn/khoa hoặc gián tiếp qua Email,
điện thoại;
- Tham gia làm chủ nhiệm hoặc cố vấn chuyên môn các Câu lạc bộ theo
phân công của khoa, bộ môn;
- Thực hiện tư vấn, hỗ trợ cho sinh viên thông qua các hệ thống Công nghệ
thông tin và truyền thông chính thức được công bố cho sinh viên; Thường xuyên
vào lớp học trực tuyến trên mô đun “Dạy học trực tuyến”, “Dạy học kết hợp” của
Hệ thống Đại học điện tử sau khi lớp học phần được thành lập để kịp thời giải đáp
thắc mắc cho sinh viên;3
e) Thực hiện đúng các quy định về hồ sơ giảng viên;
f) Chủ trì, điều phối hoạt động của trợ giảng (nếu có), của chuyên gia được
Nhà trường mời đồng giảng (nếu có) theo đúng đề cương chi tiết học phần, hướng

3 Sửa đổi, bổ sung quy định hướng dẫn giờ tự học tại Quyết định số 666/QĐ-ĐHCN ngày 01/6/2023


## Trang 11

dẫn dạy học, hướng dẫn đánh giá kết quả học tập, thời khóa biểu và lịch giảng dạy
đã được phê duyệt;
g) Viên chức, người lao động được phân công làm trợ giảng thực hiện
nhiệm vụ hỗ trợ giảng viên trong giảng dạy, giúp giảng viên trong việc phụ đạo,
hướng dẫn chuẩn bị bài, làm bài tập, thảo luận, thí nghiệm, thực hành; kiểm tra,
giám sát, khuyến khích việc tham gia học tập của sinh viên.
6. Trách nhiệm và quyền hạn của sinh viên khi tham dự các lớp học phần:
a) Được giảng viên công bố thông tin về mục tiêu, nội dung, kế hoạch dạy
học và các hình thức kiểm tra, đánh giá kết quả học tập của học phần ngay trong
buổi học đầu tiên của lớp học phần;
b) Tham gia học tập, đánh giá kết quả học tập theo đúng thời khóa biểu và
hướng dẫn của giảng viên được phân công giảng dạy lớp học phần;
d) Được tôn trọng, đối xử bình đẳng trong quá trình học tập và đánh giá kết
quả học tập;
e) Được đánh giá và tính điểm học phần trừ các trường hợp sau:
- Đối với học phần chỉ có lý thuyết hoặc học phần có cả lý thuyết và đồ án,
dự án, tiểu luận, bài tập lớn: Sinh viên vắng mặt trên lớp quá 30% số giờ học lý
thuyết không được tham dự đánh giá kết thúc học phần, nhận điểm F là điểm học
phần;
- Đối với học phần có cả lý thuyết và thực hành, thí nghiệm: Sinh viên vắng
mặt trên lớp quá 30% số giờ học lý thuyết hoặc quá 30% số giờ học thực hành,
thí nghiệm sẽ không được tham dự đánh giá kết thúc học phần, nhận điểm F là
điểm học phần;
- Đối với các học phần Thực hành, Thí nghiệm: Sinh viên vắng mặt quá
30% số giờ học thực hành, thí nghiệm phải nhận điểm F là điểm học phần;
- Đối với các học phần Tiểu luận, Bài tập lớn, Đồ án/Dự án: Sinh viên không
báo cáo kết quả quá trình thực hiện hoặc không hoàn thành nhiệm vụ theo tiến độ
thực hiện Tiểu luận, Bài tập lớn, Đồ án/Dự án quy định trong Đề cương chi tiết
học phần hoặc yêu cầu trong Phiếu giao Tiểu luận, Bài tập lớn, Đồ án/Dự án sẽ
không được tham dự đánh giá kết thúc học phần, nhận điểm F là điểm học phần.
f) Được giảng viên thông báo kết quả học tập và có thể tra cứu kết quả học
tập từ Hệ thống quản lý đào tạo sau 07 ngày làm việc kể từ ngày thực hiện bài
kiểm tra, đánh giá;
g) Được phúc tra, khiếu nại kết quả học tập trong vòng 05 ngày làm việc kể
từ ngày công bố kết quả;


## Trang 12

h) Sinh viên có quyền và trách nhiệm đóng góp ý kiến phản hồi về các điều
kiện bảo đảm chất lượng, hiệu quả học tập đối với các lớp học phần đã tham gia
học tập theo quy định tại khoản 4 Điều này.
Điều 9. Đánh giá và tính điểm học phần
1. Đối với mỗi học phần, sinh viên được đánh giá tối thiểu qua hai điểm
thành phần, đối với các học phần có khối lượng nhỏ hơn 02 tín chỉ có thể chỉ có
một điểm đánh giá. Các điểm thành phần được đánh giá theo thang điểm 10, bao
gồm: điểm làm bài tập; điểm kiểm tra thường xuyên trong quá trình học tập; điểm
đánh giá nhận thức và thái độ tham gia các hoạt động học tập trên lớp; điểm đánh
giá phần thực hành, thí nghiệm; điểm thi giữa học phần (nếu có); điểm đánh giá
kết thúc học phần (thi kết thúc học phần hoặc báo cáo tiểu luận, bài tập lớn, đồ
án/dự án nếu học phần có tín chỉ tiểu luận/bài tập lớn/đồ án/dự án). Việc lựa chọn
số lượng, phương pháp, hình thức đánh giá và trọng số để tính điểm học phần của
các điểm đánh giá thành phần được quy định trong đề cương chi tiết học phần,
trong đó:
a) Đối với các học phần chỉ có lý thuyết hoặc học phần có lý thuyết và thực
hành/thí nghiệm/tiểu luận/bài tập lớn/đồ án/dự án: Điểm đánh giá kết thúc học
phần có trọng số không dưới 50%;
b) Đối với các học phần thực hành/thí nghiệm: Điểm học phần là trung bình
có trọng số của điểm đánh giá các bài thực hành/thí nghiệm hoặc các chuẩn đầu
ra học phần, được làm tròn đến một chữ số thập phân;
c) Đối với các học phần dự án, đồ án, thực tập, kiến tập: Điểm đánh giá kết
thúc học phần có trọng số không dưới 70%.
2. Đối với các học phần trong đề cương chi tiết học phần không quy định
cụ thể về số lượng, phương pháp, hình thức đánh giá và trọng số của các điểm
thành phần, thực hiện như sau:
2.1 Các học phần chỉ có lý thuyết hoặc có cả lý thuyết và thực hành, thí
nghiệm hoặc có cả lý thuyết và đồ án, dự án, tiểu luận, bài tập lớn.
a) Cách xác định điểm trung bình các điểm trong kỳ
Thứ tự
Các loại điểm bộ phận
Hệ số
1
Điểm kiểm tra thường xuyên
1
2
Điểm thi giữa học phần
2
- Điểm trung bình các điểm trong kỳ là trung bình cộng của các điểm kiểm
tra thường xuyên, điểm thi giữa học phần theo hệ số của từng loại điểm. Điểm


## Trang 13

trung bình các điểm trong kỳ được làm tròn đến một chữ số thập phân.
- Cách tính các loại điểm:
Điểm kiểm tra thường xuyên: Gồm các điểm kiểm tra kết quả học tập hàng
ngày, điểm đánh giá các bài thực hành, thí nghiệm. Số điểm kiểm tra thường xuyên
được quy định cụ thể trong đề cương chi tiết học phần và phải đảm bảo: đối với
học phần có từ 3 tín chỉ trở xuống phải có ít nhất 2 điểm kiểm tra thường xuyên,
đối với những học phần có từ 4 tín chỉ trở lên phải có tối thiểu 2 điểm kiểm tra
thường xuyên và có 1 điểm thi giữa học phần.
Điểm thi giữa học phần: Thời điểm tổ chức thi và nội dung thi do giảng
viên giảng dạy lựa chọn trên cơ sở tổng hợp nội dung dạy học từ đầu học phần.
Thời gian làm bài thi giữa học phần từ 45 đến 90 phút.
Điểm kiểm tra thường xuyên và điểm thi giữa học phần được làm tròn đến
0,5 và được giảng viên thông báo tới sinh viên trong vòng 7 ngày làm việc kể từ
ngày thi, kiểm tra.
b) Cách xác định điểm học phần
Thứ tự
Loại điểm
Hệ số
1
Điểm trung bình các điểm trong kỳ
1
2
Điểm thi kết thúc học phần
2
- Điểm thi kết thúc học phần được làm tròn đến 0,5.
- Điểm học phần: Là trung bình cộng của điểm trung bình các điểm trong
kỳ và điểm thi kết thúc học phần theo hệ số của từng loại điểm. Điểm học phần
được tính theo thang điểm 10 (từ 0 ÷ 10), làm tròn đến một chữ số thập phân và
chuyển qua thang điểm chữ để tính điểm trung bình học kỳ, trung bình tích lũy.
2.2 Các học phần thực hành (chỉ có Thực hành/Thí nghiệm): Điểm trung
bình cộng của điểm từng bài Thực hành/Thí nghiệm trong học kỳ được làm tròn
đến một chữ số thập phân là điểm của học phần thực hành. Điểm đánh giá bài
Thực hành/Thí nghiệm làm tròn đến 0,5 và được giảng viên thông báo tới sinh
viên trong vòng 02 ngày làm việc kể từ ngày kết thúc bài Thực hành/Thí nghiệm.
2.3 Học phần Đồ án/Dự án, Bài tập lớn: Sử dụng điểm đánh giá kết thúc học
phần làm điểm học phần. Điểm đánh giá theo thang điểm 10 và làm tròn đến 0,5.
3. Hình thức đánh giá trực tuyến được áp dụng khi đảm bảo trung thực,
công bằng và khách quan như đánh giá trực tiếp, đồng thời đóng góp không quá
50% trọng số điểm học phần; riêng việc tổ chức bảo vệ và đánh giá đồ án, khóa


## Trang 14

luận được thực hiện trực tuyến với trọng số cao hơn khi đáp ứng thêm các điều
kiện sau đây:
a) Việc đánh giá được thực hiện thông qua một hội đồng chuyên môn gồm
ít nhất 3 thành viên;
b) Hình thức bảo vệ và đánh giá trực tuyến được sự đồng thuận của các
thành viên hội đồng và người học;
c) Diễn biến của buổi bảo vệ trực tuyến được ghi hình, ghi âm đầy đủ và
lưu trữ.
4. Sinh viên vắng mặt trong buổi thi, đánh giá không có lý do chính đáng
phải nhận điểm 0. Sinh viên vắng mặt có lý do chính đáng được dự thi, đánh giá
bổ sung và được tính điểm lần đầu. Đối với thi kết thúc học phần, trong 10 ngày
làm việc kể từ ngày thi, những sinh viên vắng mặt có lý do chính đáng phải làm
đơn (kèm theo hồ sơ minh chứng cho lý do vắng mặt) ký xác nhận Trưởng khoa
quản lý sinh viên để được tham dự kỳ thi bổ sung do Trung tâm Khảo thí tổ chức.
Thời gian tổ chức đợt thi bổ sung do Trung tâm Khảo thí quy định nhưng phải
đảm bảo hoàn thành kết quả thi đợt bổ sung theo quy định tại điểm d khoản 7 Điều
này. Sinh viên vắng mặt ở kỳ thi chính được bố trí dự thi ở kỳ thi bổ sung nhưng
không tham dự sẽ nhận điểm 0 là điểm thi kết thúc học phần. Sinh viên có điểm
thi kết thúc học phần bằng 0 được coi là điểm liệt và phải nhận điểm học phần là
điểm 0.4
5. Đánh giá học phần Đồ án/Khóa luận tốt nghiệp được Nhà trường quy
định trong văn bản riêng.
6. Kết quả các hoạt động thực tập tại doanh nghiệp, nghiên cứu khoa học,
thi Robocon, thi Olympic, thi tay nghề giỏi, thi xe tiết kiệm nhiên liệu, thi cuộc
đua số... được ghi nhận và có thể quy đổi tương đương với các học phần trong
chương trình đào tạo:
- Đối với các học phần thực tập tại doanh nghiệp: trước khi tổ chức chương
trình thực tập tại doanh nghiệp 01 tháng, Khoa xây dựng đề cương thực tập, đề
xuất học phần tương đương trong chương trình đào tạo và chuyển về Phòng Đào
tạo. Phòng Đào tạo xem xét, tổng hợp và trình Hiệu trưởng phê duyệt.
- Đối với các hoạt động nghiên cứu khoa học, thi Robocon, thi Olympic, thi
tay nghề giỏi, thi xe tiết kiệm nhiên liệu, thi cuộc đua số, ...: những sinh viên đạt

4 Sửa đổi, bổ sung về điểm liệt nếu điểm thi kết thúc học phần bằng 0 tại Quyết định số 666/QĐ-ĐHCN ngày
01/6/2023


## Trang 15

từ giải Ba cấp Trường trở lên (hoặc tương đương), Khoa lập danh sách (kèm theo
hồ sơ minh chứng, có xác nhận của đơn vị phụ trách lĩnh vực), đề xuất học phần
tương đương được đặc cách miễn học và điểm học phần được công nhận (tối đa
10 điểm) chuyển về Phòng Đào tạo để tổng hợp, trình Hiệu trưởng phê duyệt.
7. Điểm học phần được tính từ tổng các điểm thành phần nhân với trọng số
tương ứng, được làm tròn tới một chữ số thập phân và xếp loại điểm chữ như dưới
đây, trừ các trường hợp được quy định tại điểm d khoản này.
a) Loại đạt có phân mức, áp dụng cho các học phần được tính vào điểm
trung bình học tập, bao gồm:
A: từ 8,5 đến 10,0;
B+: từ 7,7 đến 8,4;
B: từ 7,0 đến 7,6;
C+: từ 6,2 đến 6,9;
C: từ 5,5 đến 6,1;
D+: từ 4,7 đến 5,4;
D: từ 4,0 đến 4,6.
b) Loại đạt không phân mức, áp dụng cho các học phần chỉ yêu cầu đạt,
không tính vào điểm trung bình học tập, không áp dụng đối với các học phần tăng
cường của môn học ngoại ngữ:
P: từ 5,0 trở lên.
c) Loại không đạt:
F: dưới 4,0
d) Một số trường hợp đặc biệt sử dụng các điểm chữ xếp loại, không được
tính vào điểm trung bình học tập:
I: Điểm chưa hoàn thiện do được phép hoãn thi, kiểm tra. Trong 02 học kỳ
chính tiếp theo, sinh viên có điểm I phải trả xong các nội dung còn nợ để được
chuyển điểm. Nếu không hoàn thành sinh viên phải nhận điểm 0 đối với các điểm
đánh giá còn thiếu;
X: Điểm chưa hoàn thiện do chưa đủ dữ liệu. Điểm X được áp dụng đối với
những học phần mà Phòng Đào tạo chưa nhận được báo cáo kết quả học tập của
sinh viên từ Khoa quản lý học phần hoặc Trung tâm Khảo thí chuyển đến; Trong
01 học kỳ chính tiếp theo, Trung tâm Khảo thí chịu trách nhiệm hoàn thiện các
nội dung để được chuyển điểm;
R: Điểm học phần được miễn học và công nhận tín chỉ. Điểm R được áp
dụng cho những học phần được miễn học và công nhận tín chỉ khi sinh viên


## Trang 16

chuyển từ cơ sở đào tạo khác đến hoặc học liên thông lên trình độ đại học, liên
thông sang ngành học khác;
e) Sinh viên có điểm I và điểm X sau khi hoàn thiện, chuyển điểm được
tính lần đầu và dùng để tính điểm trung bình tích lũy.5
8. Học lại, thi và học cải thiện điểm:
a) Sinh viên có học phần không đạt phải đăng ký học lại theo quy định tại
khoản 1 Điều 3 của Quy chế này, trừ trường hợp quy định tại điểm c khoản 8 Điều
này; điểm học lần cuối là điểm chính thức của học phần;
b) Sinh viên được quyền đăng ký học lại, học đổi (đối với các học phần tự
chọn) các học phần đạt để cải thiện điểm. Điểm cao nhất trong các lần học sẽ được
dùng để tính điểm trung bình học kỳ, trung bình tích lũy. Nhà trường không giới
hạn số lần đăng ký học lại hoặc học đổi trong thời gian sinh viên được phép hoàn
thành chương trình theo quy định. Sinh viên có thể đăng ký học lại, học đổi trong
học kỳ chính hoặc học kỳ phụ theo kế hoạch tổ chức đào tạo của Nhà trường. Thủ
tục đăng ký học lại, học đổi giống như đối với đăng ký một học phần mới;
c) Lưu học sinh được phép đăng ký đánh giá lại bài đánh giá kết thúc học
phần để cải thiện điểm học phần từ không đạt thành đạt; trong trường hợp này,
điểm học phần được giới hạn tối đa ở mức điểm C+ sau khi đánh giá lại. Thời
gian tiếp nhận đề nghị đánh giá lại bài đánh giá kết thúc học phần của sinh viên
trong vòng 03 ngày làm việc kể từ ngày công bố điểm học phần. Trung tâm Khảo
thí tiếp nhận và phối hợp với Khoa để giải quyết đề nghị của sinh viên; cập nhật
kết quả vào Hệ thống quản lý đào tạo của Nhà trường sau khi đánh giá lại trong
vòng 10 ngày làm việc kể từ ngày công bố điểm học phần.
Điều 10. Đánh giá kết quả học tập trong học kỳ, trong năm học, từ đầu
khóa học
1. Kết quả học tập trong học kỳ, trong năm học, từ đầu khóa học của sinh
viên được đánh giá dựa trên kết quả các học phần nằm trong yêu cầu của chương
trình đào tạo mà sinh viên đã học và có điểm theo các tiêu chí sau đây:
a) Tổng số tín chỉ của những học phần trong chương trình đào tạo dùng để
tính điểm mà sinh viên không đạt trong một học kỳ, trong một năm học, hoặc nợ
đọng từ đầu khoá học;
b) Tổng số tín chỉ của những học phần trong chương trình đào tạo dùng để
tính điểm mà sinh viên đã đạt từ đầu khóa học (số tín chỉ tích lũy), tính cả các học

5 Quy định điểm đạt không phân mức đối với các học phần Tiếng Anh tăng cường tại Quyết định số 666/QĐ-
ĐHCN ngày 01/6/2023


## Trang 17

phần được miễn học, được công nhận tín chỉ;
c) Điểm trung bình của những học phần trong chương trình đào tạo dùng
để tính điểm mà sinh viên đã học trong một học kỳ (điểm trung bình học kỳ), trong
một năm học (điểm trung bình năm học), được tính bằng trung bình cộng có trọng
số các điểm chính thức của học phần với trọng số là số tín chỉ của học phần, làm
tròn đến hai chữ số thập phân;
Điểm trung bình của những học phần trong chương trình đào tạo dùng để
tính điểm mà sinh viên đã học và đạt từ đầu khóa học (điểm trung bình tích lũy),
được tính bằng trung bình cộng có trọng số các điểm chính thức của học phần với
trọng số là số tín chỉ của học phần, làm tròn đến hai chữ số thập phân;
Trong học kỳ, năm học, khóa học, nếu sinh viên học một học phần nhiều
lần thì điểm cao nhất trong các lần học của sinh viên được dùng để tính điểm trung
bình học kỳ, năm học, tích lũy.
Kết quả học tập trong học kỳ phụ được tính vào kết quả học tập của học kỳ
chính tổ chức ngay trước học kỳ phụ để tính các điểm trung bình trong các đợt xét
học tiếp, xét tốt nghiệp và xếp loại học lực, xếp trình độ năm học của sinh viên.
2. Để tính điểm trung bình, điểm chữ của học phần được quy đổi về điểm
số tương ứng theo thang từ 0 tới 4 như sau:
A quy đổi thành 4,0;
B+ quy đổi thành 3,5;
B quy đổi thành 3,0;
C+ quy đổi thành 2,5;
C quy đổi thành 2,0;
D+ quy đổi thành 1,5;
D quy đổi thành 1,0;
F quy đổi thành 0.
3. Một số quy định khác:
a) Những điểm chữ không được quy định tại khoản 2 Điều này không được
tính vào các điểm trung bình học kỳ, năm học hoặc tích lũy. Những học phần
không nằm trong yêu cầu của chương trình đào tạo không được tính vào các tiêu
chí đánh giá kết quả học tập của sinh viên;
b) Nếu số lượng học phần trong nhóm tự chọn mà sinh viên tích lũy lớn
hơn số lượng học phần quy định phải tích lũy trong nhóm tự chọn, sẽ dùng điểm
các học phần cao nhất, đủ số lượng học phần và số tín chỉ theo quy định của nhóm
để tính điểm trung bình tích lũy. Trường hợp số tín chỉ các học phần tự chọn vượt


## Trang 18

quá số tín chỉ quy định nhưng kết quả học tập của các học phần bằng nhau sinh
viên được lựa chọn học phần dùng để tính điểm trung bình tích lũy trong việc xét
tốt nghiệp;
c) Những học phần sinh viên đã được miễn học và công nhận tín chỉ nhưng
sinh viên đăng ký học, được đánh giá đạt sẽ dùng để tính điểm trung bình tích lũy;
d) Trường hợp sinh viên không dùng hoặc dùng điểm của học phần khác để
tính điểm trung bình tích lũy được quy định tại điểm b, điểm c khoản 3 Điều này
phải làm đơn gửi Phòng Đào tạo trước thời điểm xét công nhận tốt nghiệp 01 tuần.
4. Sinh viên được xếp loại học lực theo điểm trung bình học kỳ, điểm trung
bình năm học hoặc điểm trung bình tích lũy như sau:
Từ 3,60 đến 4,00: Xuất sắc;
Từ 3,20 đến 3,59: Giỏi;
Từ 2,50 đến 3,19: Khá;
Từ 2,00 đến 2,49: Trung bình;
Từ 1,00 đến 1,99: Yếu;
Dưới 1,00: Kém.
5. Sinh viên được xếp trình độ năm học căn cứ số tín chỉ tích lũy từ đầu
khóa học (gọi tắt là KLTL) và số tín chỉ quy định cho chương trình đào tạo (gọi
tắt là KLCT), cụ thể như sau:
a) Trình độ năm thứ nhất: KLTL ≤ 1/4 KLCT;
b) Trình độ năm thứ hai: 1/4 KLCT < KLTL ≤ 1/2 KLCT;
c) Trình độ năm thứ ba: 1/2 KLCT < KLTL ≤ 3/4 KLCT;
d) Trình độ năm cuối khóa: KLTL > 3/4 KLCT.6
Điều 11. Xử lý kết quả học tập theo tín chỉ
1. Sinh viên được cảnh báo học tập của học kỳ nếu vi phạm một trong các
trường hợp sau:
a) Điểm trung bình học kỳ đạt dưới 0,80 đối với học kỳ đầu của khóa học,
dưới 1,00 đối với các học kỳ tiếp theo;
b) Điểm trung bình tích lũy đạt dưới 1,20 đối với sinh viên trình độ năm
thứ nhất; dưới 1,40 đối với sinh viên trình độ năm thứ hai; dưới 1,60 đối với sinh
viên trình độ năm thứ ba và dưới 1,80 đối với sinh viên các năm tiếp theo.
2. Sinh viên bị buộc thôi học trong các trường hợp sau:

6 Tường minh quy định tính điểm trung bình học kỳ, điểm của học kỳ phụ tại Quyết định số 666/QĐ-ĐHCN ngày
01/6/2023


## Trang 19

a) Lần thứ 2 liên tiếp có kết quả học tập rơi vào các trường hợp thuộc điểm
a hoặc điểm b khoản 1 Điều này;
b) Vượt quá thời gian tối đa được phép học quy định tại khoản 5 Điều 2 của
Quy chế này;
c) Không đăng ký khối lượng học tập trong 02 học kỳ chính liên tiếp.
3. Cảnh báo kết quả học tập và buộc thôi học sinh viên được quy định tại
khoản 1, khoản 2 Điều này. Phòng Đào tạo thông báo kế hoạch xét học tiếp và mở
đợt xét học tiếp trên Hệ thống quản lý đào tạo của Nhà trường để các Khoa thực
hiện xét học tiếp lên học kỳ tiếp theo cho sinh viên của Khoa quản lý. Các Khoa
quản lý sinh viên chịu trách nhiệm rà soát đảm bảo chính xác, in và ký danh sách
sinh viên được cảnh báo kết quả học tập, sinh viên bị buộc thôi học trong học kỳ
gửi Hiệu trưởng thông qua Phòng Đào tạo. Phòng Đào tạo kiểm tra và tiếp nhận
hồ sơ sau đó lập quyết định trình Hiệu trưởng ký ban hành.
4. Trưởng khoa quản lý sinh viên chịu trách nhiệm về việc thông báo cho
sinh viên: trong vòng 10 ngày làm việc đối với trường hợp bị cảnh báo kết quả
học tập của học kỳ, trong vòng 01 tháng đối với trường hợp không đủ điều kiện
học tiếp kể từ ngày Hiệu trưởng ký quyết định ban hành.
5. Việc bảo lưu kết quả học tập đã tích luỹ trong trường hợp sinh viên bị
buộc thôi học được quy định tại Điều 14.7
Điều 12. Công nhận kết quả học tập và chuyển đổi tín chỉ
1. Kết quả học tập ngoài trường, kết quả học tập đã có trước khi nhập học
của sinh viên được Hội đồng chuyên môn của Khoa (Hội đồng khoa học và đào
tạo hoặc Hội đồng ngành) xem xét, đề nghị Trưởng khoa trình Hiệu trưởng phê
duyệt miễn học, công nhận tín chỉ cho sinh viên trong những trường hợp như sau:
a) Kết quả học tập ở trình độ trung cấp, cao đẳng của sinh viên trúng tuyển
liên thông lên trình độ đại học;
b) Kết quả học tập ở trình độ đại học của sinh viên trúng tuyển và học liên
thông để nhận thêm một văn bằng tốt nghiệp đại học của một ngành đào tạo khác;
c) Kết quả học tập của sinh viên tại các cơ sở giáo dục đại học khác nay
chuyển về học tại Nhà trường;
d) Kết quả học tập của sinh viên tại các cơ sở đào tạo khác theo chương
trình trao đổi sinh viên được ký kết;

7 Sửa đổi về thời gian xét học tiếp, quy định về trách nhiệm của các Đơn vị trong việc xét học tiếp tại Quyết định
số 666/QĐ-ĐHCN ngày 01/6/2023.


## Trang 20

e) Đối với các học phần: Thực tập tốt nghiệp, Thực tập doanh nghiệp, sinh
viên được phép thực hiện tại cơ sở đào tạo khác theo chương trình trao đổi sinh
viên nhưng phải báo cáo kết quả thực tập tại trường để được đánh giá và cho điểm.
Trường hợp đặc biệt do Hiệu trưởng quyết định.
2. Hội đồng chuyên môn của Khoa xem xét và đề nghị Trưởng khoa công
nhận, chuyển đổi tín chỉ trên cơ sở đối sánh chuẩn đầu ra, nội dung và khối lượng
học tập, cách thức đánh giá học phần và các điều kiện bảo đảm chất lượng thực
hiện chương trình theo từng học phần.
3. Khối lượng tín chỉ tối đa sinh viên được công nhận, chuyển đổi không
vượt quá 50% khối lượng học tập tối thiểu của chương trình đào tạo.
Điều 13. Công nhận tốt nghiệp và cấp bằng tốt nghiệp
1. Sau mỗi học kỳ, sinh viên được Nhà trường xét và công nhận tốt nghiệp
khi có đủ các điều kiện sau:
a) Tích lũy đủ học phần, số tín chỉ theo yêu cầu của chương trình đào tạo,
đạt chuẩn đầu ra của chương trình đào tạo;
b) Hoàn thành các môn học Giáo dục quốc phòng-an ninh, Giáo dục thể chất;
c) Hoàn thành các môn học Kỹ năng sử dụng công nghệ thông tin, Ngoại
ngữ và các môn học khác (nếu có) theo yêu cầu của chương trình đào tạo;
d) Điểm trung bình tích lũy đạt từ 2,00 trở lên;
e) Tại thời điểm xét tốt nghiệp không bị truy cứu trách nhiệm hình sự hoặc
không đang trong thời gian bị kỷ luật ở mức đình chỉ học tập.
2. Quy trình xét và công nhận tốt nghiệp:
a) Trước mỗi đợt xét tốt nghiệp 01 tháng, Nhà trường thông báo đến sinh
viên trên cổng thông tin điện tử dành cho sinh viên (https://sv.dhcnhn.vn) để sinh
viên kiểm tra các nội dung về: kết quả học tập, thông tin cá nhân sẽ được in trên
bằng tốt nghiệp, các điều kiện Giáo dục thể chất, Giáo dục quốc phòng-an ninh,
Ngoại ngữ, Kỹ năng sử dụng công nghệ thông tin, ... Nếu có sai sót, sinh viên đề
nghị sửa sai thông tin cá nhân hoặc gửi khiếu nại, thắc mắc về kết quả học tập
theo các quy trình, hướng dẫn Nhà trường đã ban hành;
b) Phòng Đào tạo mở đợt xét trên Hệ thống quản lý đào tạo để các Khoa
thực hiện xét tốt nghiệp. Trưởng khoa chịu trách nhiệm trong việc kiểm tra và lập
danh sách sinh viên đủ điều kiện tốt nghiệp đề nghị Hiệu trưởng công nhận tốt
nghiệp thông qua Phòng Đào tạo;8

8 Quy định trách nhiệm của các Đơn vị trong việc xét tốt nghiệp tại Quyết định số 666/QĐ-ĐHCN ngày 01/6/2023.


## Trang 21

c) Trong vòng 10 ngày làm việc kể từ ngày Khoa gửi danh sách sinh viên
đủ điều kiện tốt nghiệp, Phòng Đào tạo thực hiện kiểm tra, tổng hợp, phản hồi sai
sót và lập danh sách sinh viên tốt nghiệp trình Hiệu trưởng ký quyết định công
nhận tốt nghiệp cho sinh viên.
3. Quy định đối với sinh viên đủ điều kiện tốt nghiệp:
a) Sinh viên đủ điều kiện tốt nghiệp được Hiệu trưởng ký quyết định công
nhận tốt nghiệp, cấp bằng tốt nghiệp và phụ lục văn bằng tốt nghiệp trong thời
hạn 03 tháng tính từ thời điểm sinh viên đáp ứng đầy đủ điều kiện tốt nghiệp và
hoàn thành mọi nghĩa vụ đối với Nhà trường;9
b) Trong thời gian chờ cấp bằng tốt nghiệp, Phòng Đào tạo chịu trách nhiệm
cấp Giấy chứng nhận tốt nghiệp tạm thời cho sinh viên đã được công nhận tốt nghiệp;
c) Sinh viên muốn học cải thiện điểm để nâng hạng tốt nghiệp phải làm đơn
đề nghị hoãn tốt nghiệp trước khi Khoa gửi danh sách sinh viên đủ điều kiện tốt
nghiệp theo quy định tại điểm b khoản 2 Điều này.
4. Hạng tốt nghiệp được xác định căn cứ vào điểm trung bình tích lũy toàn
khoá được quy định tại khoản 4 Điều 10 của Quy chế này. Hạng tốt nghiệp của
sinh viên có điểm trung bình tích lũy loại xuất sắc và giỏi sẽ bị giảm đi một mức
nếu thuộc một trong các trường hợp sau:
a) Khối lượng của các học phần phải học lại có tổng số tín chỉ vượt quá 5%
so với tổng số tín chỉ quy định cho toàn chương trình (áp dụng đối với sinh viên
tuyển sinh, đào tạo từ ngày 3 tháng 5 năm 2021 trở đi);
b) Sinh viên đã bị kỷ luật từ mức cảnh cáo trở lên trong thời gian học.
5. Sinh viên đã hết thời gian học tập tối đa theo quy định nhưng chưa đủ
điều kiện tốt nghiệp do chưa hoàn thành các môn học Giáo dục quốc phòng-an
ninh, Giáo dục thể chất, Kỹ năng sử dụng công nghệ thông tin, Ngoại ngữ hoặc
các môn học khác (nếu có) theo yêu cầu của chương trình đào tạo, trong thời hạn
05 năm (áp dụng cho sinh viên tuyển sinh, đào tạo trước ngày 3 tháng 5 năm
2021), 03 năm (áp dụng cho sinh viên tuyển sinh, đào tạo từ ngày 3 tháng 5 năm
2021 trở đi) tính từ khi bị buộc thôi học được hoàn thiện các điều kiện còn thiếu
và đề nghị xét công nhận tốt nghiệp;
6. Sinh viên không tốt nghiệp được Nhà trường cấp chứng nhận hoàn thành
các học phần đã tích lũy trong thời gian học tập.
Điều 14. Nghỉ học tạm thời, thôi học

9 Bổ sung quy định cấp Phụ lục văn bằng cho sinh viên tốt nghiệp.


## Trang 22

1. Sinh viên được nghỉ học tạm thời và bảo lưu kết quả đã học trong các
trường hợp sau:
a) Được điều động vào lực lượng vũ trang;
b) Được cơ quan có thẩm quyền điều động, đại diện quốc gia tham dự các
kỳ thi, giải đấu quốc tế;
c) Bị ốm, thai sản hoặc tai nạn phải điều trị thời gian dài có chứng nhận của
cơ sở khám bệnh, chữa bệnh có thẩm quyền theo quy định của Bộ Y tế;
d) Vì lý do cá nhân khác nhưng đã phải học tối thiểu 01 học kỳ tại Nhà trường
và không thuộc các trường hợp bị xem xét buộc thôi học hoặc xem xét kỷ luật.
2. Thời gian nghỉ học tạm thời vì lý do cá nhân được tính vào thời gian học
chính thức quy định tại khoản 5 Điều 2 của Quy chế này.
3. Thủ tục cho sinh viên nghỉ học tạm thời:
a) Sinh viên hoàn thành các nghĩa vụ đối với Nhà trường, làm đơn xin nghỉ
học tạm thời và kèm theo các hồ sơ minh chứng;
b) Trưởng khoa tiếp nhận hồ sơ, đối chiếu các quy định tại khoản 1 Điều
này và ký xác nhận trước khi gửi về Phòng Đào tạo;
c) Phòng Đào tạo kiểm tra hồ sơ, ra quyết định cho sinh viên nghỉ học tạm
thời và trình Hiệu trưởng ký duyệt.
4. Sinh viên nghỉ học tạm thời có kế hoạch trở lại học tập phải làm đơn gửi về
Khoa trước thời điểm bắt đầu đăng ký khối lượng học tập của học kỳ ít nhất 02 tuần.
Khoa tiếp nhận, kiểm tra và gửi hồ sơ về Phòng Đào tạo trong 01 tuần kể
từ ngày nhận đơn của sinh viên;
Phòng Đào tạo ra quyết định tiếp nhận sinh viên trở lại học tiếp trình Hiệu
trưởng ký duyệt trước khi bắt đầu học kỳ 02 tuần.
5. Sinh viên có nguyện vọng được thôi học vì lý do cá nhân, trừ trường hợp
bị xem xét buộc thôi học hoặc xem xét kỷ luật, làm đơn xin thôi học gửi Hiệu
trưởng thông qua Phòng Công tác Sinh viên. Sinh viên được cấp chứng nhận về
các học phần đã tích lũy trong chương trình đào tạo khi có quyết định cho thôi
học và hoàn thành các nghĩa vụ đối với Nhà trường. Sau khi có quyết định cho
thôi học, sinh viên muốn quay trở lại học phải dự tuyển sinh đầu vào như những
thí sinh khác.
Điều 15. Sinh viên chuyển trường, chuyển ngành/chương trình đào tạo
1. Sinh viên của các cơ sở giáo dục đại học khác được xét chuyển vào học
tại Trường nếu thoả mãn các điều kiện sau đây:


## Trang 23

a) Không đang là sinh viên trình độ năm thứ nhất hoặc năm cuối khóa,
không thuộc diện bị xem xét buộc thôi học và còn đủ thời gian học tập theo quy
định tại khoản 5 Điều 2 của Quy chế này;
b) Đạt điều kiện trúng tuyển trong cùng khóa tuyển sinh của ngành/chương
trình đào tạo có nguyện vọng được chuyển đến;
c) Nhà trường có đủ các điều kiện bảo đảm chất lượng, chưa vượt quá năng lực
đào tạo đối với ngành/chương trình đào tạo sinh viên có nguyện vọng chuyển đến;
 d) Được Hiệu trưởng trường đang học chấp nhận.10
2. Thủ tục chuyển đến Trường Đại học Công nghiệp Hà Nội:
a) Sinh viên chuyển đến phải có đủ hồ sơ chuyển trường bao gồm: đơn xin
chuyển trường (theo mẫu), hồ sơ minh chứng đạt điều kiện trúng tuyển của
chương trình/ngành đào tạo có nguyện vọng được chuyển đến (giấy chứng nhận
kết quả thi tốt nghiệp trung học phổ thông/thi trung học phổ thông quốc gia, giấy
báo trúng tuyển, ...), bảng kết quả học tập sinh viên có xác nhận của trường đang
theo học, sơ yếu lý lịch;
b) Phòng Đào tạo tiếp nhận hồ sơ, đối chiếu các quy định tại khoản 1 Điều
này đề xuất Hiệu trưởng quyết định tiếp nhận hoặc không tiếp nhận. Nếu được
tiếp nhận, Phòng Đào tạo chuyển kết quả học tập của sinh viên đã tích lũy cho
Khoa quản lý ngành/chương trình đào tạo thực hiện xét miễn học và công nhận
tín chỉ theo quy định tại khoản 1 Điều 12.
3. Sinh viên chuyển đi khỏi Trường Đại học Công nghiệp Hà Nội phải làm
đơn gửi Hiệu trưởng thông qua Phòng Đào tạo sau khi đã hoàn thành các nghĩa
vụ đối với Nhà trường.
4. Sinh viên được chuyển ngành/chương trình đào tạo nếu thỏa mãn các
điều kiện sau:
a) Sinh viên đã học xong 02 học kỳ chính đầu tiên của khóa học;
b) Thỏa mãn điều kiện trúng tuyển của ngành/chương trình có nguyện vọng
được chuyển đến;
c) Được chuyển duy nhất 1 lần trong khóa học;
d) Ngành/chương trình đào tạo sinh viên có nguyện vọng được chuyển đến
còn chỉ tiêu đào tạo. Trong trường hợp số sinh viên có nguyện vọng được chuyển
đến lớn hơn chỉ tiêu còn lại của ngành/chương trình đào tạo cho phép thì ưu tiên
sinh viên có điểm trung bình tích lũy cao hơn.

10 Điều chỉnh các điều kiện chuyển trường tại Quyết định số 666/QĐ-ĐHCN ngày 01/6/2023


## Trang 24

5. Thủ tục chuyển ngành/chương trình đào tạo:
a) Sinh viên làm đơn (theo mẫu);
b) Phòng Đào tạo tiếp nhận đơn và đối chiếu các điều kiện tại khoản 4 Điều
này, đề xuất Hiệu trưởng cho phép hoặc không cho phép chuyển ngành/chương
trình đào tạo;
c) Khoa có sinh viên chuyển ngành/chương trình đào tạo sinh viên có
nguyện vọng được chuyển đến xem xét bảo lưu kết quả học tập, miễn học và công
nhận tín chỉ trên cơ sở đối sánh hai chương trình đào tạo trình Hiệu trưởng phê
duyệt thông qua Phòng Đào tạo.
6. Thời gian tối đa sinh viên được phép theo học trong ngành/chương trình
đào tạo mới tính từ ngày sinh viên nhập học ngành/chương trình đào tạo trúng
tuyển vào Nhà trường.
Điều 16. Trao đổi sinh viên và hợp tác trong đào tạo
1. Nhà trường thống nhất, ký kết văn bản hợp tác đào tạo với các cơ sở đào
tạo trong việc công nhận lẫn nhau về quy trình đào tạo, nội dung đào tạo và giá
trị của tín chỉ làm căn cứ cho phép sinh viên của Nhà trường được học một số học
phần tại cơ sở đào tạo khác và ngược lại (sau đây gọi là trao đổi sinh viên).
2. Trên cơ sở đánh giá và công nhận lẫn nhau, sinh viên của Nhà trường có
thể đăng ký thực hiện học một số học phần tại cơ sở đào tạo khác, nếu được Hiệu
trưởng của hai cơ sở đào tạo đồng ý với số lượng tín chỉ mà sinh viên tích lũy tại
cơ sở đào tạo khác (nếu có) không vượt quá 25% tổng khối lượng của chương
trình đào tạo.
3. Trong hợp tác đào tạo giữa Nhà trường và cơ sở đào tạo khác (sau đây
gọi là cơ sở phối hợp đào tạo), việc đánh giá và công nhận số lượng tín chỉ mà
sinh viên tích lũy tại cơ sở phối hợp đào tạo không vượt quá 25% tổng khối lượng
của chương trình đào tạo.
4. Điều kiện trao đổi sinh viên, công nhận kết quả học tập và chuyển đổi tín
chỉ cho sinh viên được quy định cụ thể trong văn bản hợp tác đào tạo Nhà trường
ký kết với cơ sở phối hợp đào tạo theo khoản 1 Điều này.11
Điều 17. Học cùng lúc hai chương trình
1. Sinh viên có thể đăng ký học thêm các học phần của một chương trình
khác, ngành khác nhưng chỉ được hưởng các quyền lợi chính thức và được xem
xét công nhận tốt nghiệp chương trình thứ hai khi đã đăng ký thành công học

11 Quy định rõ hơn về trao đổi và hợp tác trong đào tạo tại Quyết định số 666/QĐ-ĐHCN ngày 01/6/2023


## Trang 25

chương trình thứ hai theo quy định tại khoản 2 Điều này.
2. Sinh viên được đăng ký học chương trình thứ hai sớm nhất khi đã được
xếp trình độ năm thứ hai của chương trình thứ nhất. Tại thời điểm đăng ký, sinh
viên phải đáp ứng 01 trong 02 điều kiện sau:
a) Học lực tính theo điểm trung bình tích lũy xếp loại khá trở lên và đáp
ứng ngưỡng bảo đảm chất lượng của chương trình thứ hai trong năm tuyển sinh;
b) Học lực tính theo điểm trung bình tích lũy xếp loại trung bình và đáp ứng
điều kiện trúng tuyển của chương trình thứ hai trong năm tuyển sinh.
3. Trong quá trình sinh viên học cùng lúc hai chương trình, nếu điểm trung
bình tích luỹ của chương trình thứ nhất đạt dưới điểm trung bình hoặc thuộc diện
cảnh báo kết quả học tập thì phải dừng học chương trình thứ hai ở học kỳ tiếp theo
và bị loại khỏi danh sách đã đăng ký học chương trình thứ hai.
4. Thời gian tối đa được phép học đối với sinh viên học cùng lúc hai chương
trình là thời gian tối đa quy định cho chương trình thứ nhất, quy định tại khoản 5
Điều 2 của Quy chế này. Khi học chương trình thứ hai, sinh viên được công nhận
kết quả của những học phần có nội dung và khối lượng kiến thức tương đương
trong chương trình thứ nhất.
5. Sinh viên chỉ được xét tốt nghiệp chương trình thứ hai, nếu có đủ điều
kiện tốt nghiệp ở chương trình thứ nhất và đã đăng kí học chương trình thứ hai
muộn nhất 02 năm trước thời điểm xét tốt nghiệp chương trình thứ hai.
Điều 18. Học liên thông đối với người có văn bằng khác
1. Người đã tốt nghiệp các trình độ đào tạo của giáo dục nghề nghiệp được
dự tuyển và học liên thông lên trình độ đại học theo quy định hiện hành của Chính
phủ, Thủ tướng Chính phủ, Bộ Giáo dục và Đào tạo và của Nhà trường.
2. Người đã tốt nghiệp đại học được dự tuyển và học liên thông để nhận
thêm một bằng tốt nghiệp đại học của một ngành đào tạo khác.
3. Người học liên thông thực hiện chương trình đào tạo và đăng ký học tập
theo kế hoạch chung như các sinh viên khác cùng hình thức đào tạo. Trên cơ sở
công nhận và chuyển đổi tín chỉ, sinh viên được miễn trừ các học phần tương ứng
với các học phần được miễn học, công nhận tín chỉ theo quy định tại Điều 12 của
Quy chế này.
4. Điều kiện, thủ tục tiếp nhận học liên thông lên trình độ đại học thực hiện
theo quy định hiện hành của Chính phủ, Thủ tướng Chính phủ, Bộ Giáo dục và
Đào tạo và quy chế tuyển sinh của Nhà trường.
Điều 19. Xử lý vi phạm đối với sinh viên


## Trang 26

1. Sinh viên có gian lận trong khi dự kiểm tra thường xuyên, chuẩn bị tiểu
luận, bài tập lớn, dự án, đồ án, thi giữa học phần, thi kết thúc học phần, chuẩn bị
đồ án, khoá luận tốt nghiệp sẽ bị xử lý kỷ luật với từng học phần đã vi phạm theo
các quy định của Quy chế thi tốt nghiệp Trung học phổ thông hiện hành do Bộ
Giáo dục và Đào tạo ban hành, trừ trường hợp quy định tại khoản 2 Điều này.
2. Sinh viên thi hộ hoặc nhờ người thi hộ đều bị kỷ luật ở mức đình chỉ học
tập 01 năm đối với trường hợp vi phạm lần thứ nhất và buộc thôi học đối với
trường hợp vi phạm lần thứ hai.
3. Người học sử dụng hồ sơ, văn bằng, chứng chỉ giả làm điều kiện trúng
tuyển hoặc điều kiện tốt nghiệp sẽ bị buộc thôi học; văn bằng tốt nghiệp nếu đã
được cấp sẽ bị thu hồi, huỷ bỏ.
Điều 20. Xây dựng và thực hiện quy chế
1. Căn cứ Quy chế này và các quy định hiện hành khác có liên quan, Hiệu
trưởng Nhà trường có trách nhiệm:
a) Ban hành các quyết định tổ chức đào tạo chính quy, vừa làm vừa học,
liên kết đào tạo, đào tạo liên thông (nếu có) bảo đảm đầy đủ các yêu cầu theo Quy
chế này; trong đó phải ghi rõ tên ngành, hình thức đào tạo, đối tượng, chỉ tiêu và
phương thức tuyển sinh, địa điểm đào tạo, cơ sở phối hợp đào tạo và các thông tin
khác có liên quan;
b) Tổ chức phổ biến, hướng dẫn cho sinh viên quy chế của Nhà trường và
các quy định liên quan đến quá trình học tập, các quy định về nghĩa vụ và quyền
lợi của sinh viên ngay đầu khóa học;
c) Xây dựng, ban hành các quy định, thủ tục quy trình và hướng dẫn (nếu
có) để thực hiện quy chế một cách đồng bộ, thống nhất trong toàn Trường;
d) Tổ chức kiểm tra, thanh tra nội bộ việc thực hiện kế hoạch, chương trình,
quy chế và các nhiệm vụ khác liên quan đến đào tạo; chịu sự kiểm tra, thanh tra,
giám sát của Bộ Giáo dục và Đào tạo và các cơ quan có thẩm quyền theo các quy
định hiện hành.
2. Nhà trường thực hiện giải trình theo quy định tại khoản 4 Điều 13 Nghị
định số 99/2019/NĐ-CP ngày 30 tháng 12 năm 2019 của Chính phủ quy định chi
tiết và hướng dẫn thi hành một số điều của Luật sửa đổi bổ sung một số điều của
Luật Giáo dục đại học và các quy định khác của pháp luật có liên quan.
3. Căn cứ Quy chế này và các quy định hiện hành khác có liên quan của
Trường, Trưởng khoa có trách nhiệm:


## Trang 27

a) Phổ biến, hướng dẫn cho giảng viên, chuyên viên, nhân viên quy chế của
Nhà trường và các quy định, thủ tục quy trình, hướng dẫn liên quan đến quá trình
dạy học, các quy định về nghĩa vụ và quyền lợi của giảng viên;
b) Phổ biến, hướng dẫn cho sinh viên quy chế của Nhà trường và các quy
định, thủ tục quy trình, hướng dẫn liên quan đến quá trình học tập, các quy định
về nghĩa vụ và quyền lợi của sinh viên ngay đầu khóa học;
c) Tổ chức kiểm tra nội bộ việc thực hiện kế hoạch, chương trình, quy chế
và các nhiệm vụ khác liên quan đến đào tạo; chịu sự kiểm tra, thanh tra, giám sát
của Phòng Thanh tra Giáo dục, Phòng Đào tạo và các đơn vị chức năng khác theo
quy định của Nhà trường.
Điều 21. Chế độ báo cáo, lưu trữ, công khai thông tin
1. Trước ngày 31 tháng 12 hàng năm:
a) Nhà trường báo cáo Bộ Giáo dục và Đào tạo và cơ quan quản lý trực tiếp
về số liệu sinh viên tuyển mới, tốt nghiệp, thôi học và đang học trong năm, dự kiến
tốt nghiệp trong năm sau, tốt nghiệp đã có việc làm trong thời gian 12 tháng; phân
loại theo đối tượng đầu vào, ngành đào tạo, khóa đào tạo và hình thức đào tạo;
b) Nhà trường báo cáo Ủy ban nhân dân cấp tỉnh nơi liên kết đào tạo về tình
hình tuyển sinh và đào tạo tại địa phương.
2. Nhà trường có trách nhiệm lưu trữ, bảo quản an toàn các tài liệu liên quan
tới công tác đào tạo theo các quy định do Bộ Giáo dục và Đào tạo ban hành:
a) Quyết định trúng tuyển, bảng điểm gốc, quyết định công nhận tốt nghiệp,
sổ gốc cấp phát bằng tốt nghiệp cho sinh viên là tài liệu lưu trữ được bảo quản
vĩnh viễn;
b) Tài liệu khác liên quan đến tuyển sinh, đào tạo được lưu trữ, bảo quản
trong suốt quá trình đào tạo;
c) Việc tiêu hủy tài liệu liên quan tuyển sinh, đào tạo hết thời gian lưu trữ
được thực hiện theo quy định hiện hành của nhà nước.
3. Nhà trường công khai trên cổng thông tin điện tử chậm nhất 45 ngày
trước khi tổ chức đào tạo:
a) Quy chế và các quy định quản lý đào tạo có liên quan;
b) Quyết định mở ngành và các quyết định nêu tại điểm b khoản 1 Điều 21
đối với chương trình sẽ tổ chức đào tạo;
c) Các điều kiện bảo đảm chất lượng theo quy định hiện hành của Bộ Giáo
dục và Đào tạo;
d) Các minh chứng về việc các chương trình đào tạo đáp ứng chuẩn chương


## Trang 28

trình đào tạo do Bộ Giáo dục và Đào tạo ban hành;
đ) Thông báo tuyển sinh theo quy chế tuyển sinh hiện hành;
e) Các minh chứng về việc đáp ứng các yêu cầu tối thiểu đối với liên kết
đào tạo vừa làm vừa học theo quy định tại khoản 2 và khoản 3 Điều 5 của Quy
chế này.
4. Khoa thực hiện chế độ báo cáo, lưu trữ, bảo quản tài liệu và công khai
thông tin theo quy định do Nhà trường ban hành.
Điều 22. Điều khoản thi hành
1. Quy chế này áp dụng đối với tất cả các khóa tuyển sinh và đào tạo trình
độ đại học tại Trường Đại học Công nghiệp Hà Nội.
2. Quy chế này thay thế Quy chế Đào tạo đại học hệ vừa làm vừa học theo
học chế tín chỉ tại Trường Đại học Công nghiệp Hà Nội ban hành kèm theo Quyết
định số 1017/QĐ-ĐHCN ngày 5 tháng 9 năm 2016 của Trường Đại học Công
nghiệp Hà Nội; Quy định liên kết đào tạo trình độ đại học của Trường Đại học
Công nghiệp Hà Nội ban hành kèm theo Quyết định số 479/QĐ-ĐHCN ngày 8
tháng 5 năm 2018 của Trường Đại học Công nghiệp Hà Nội; Quy chế Đào tạo đại
học và cao đẳng hệ chính quy theo học chế tín chỉ tại Trường Đại học Công nghiệp
Hà Nội ban hành kèm theo Quyết định số 787/QĐ-ĐHCN ngày 9 tháng 8 năm
2018 của Trường Đại học Công nghiệp Hà Nội; Sửa đổi, bổ sung một số nội dung
Quy chế đào tạo đại học và cao đẳng hệ chính quy theo học chế tín chỉ ban hành
tại Quyết định số 787/QĐ-ĐHCN ngày 9 tháng 8 năm 2018 của Trường Đại học
Công nghiệp Hà Nội ban hành kèm theo Quyết định số 663/QĐ-ĐHCN ngày 12
tháng 7 năm 2019 của Trường Đại học Công nghiệp Hà Nội./.
